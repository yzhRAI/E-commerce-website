using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����product ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class product
	{
		public product()
		{}
		#region Model
		private int _pid;
		private int? _classid;
		private int? _classxid;
		private string _productname;
		private string _productintroduce;
		private string _productchu;
		private string _productimage;
		private decimal? _masterprice;
		private decimal? _hotprice;
		private int _newproduct;
		private string _guige;
		private string _productguanjian;
		private DateTime? _adddate;
		private int? _pkc;
		private int? _sl;
		private int? _hittimes;
		private int? _jifen;
		private string _zenpin;
		/// <summary>
		/// 
		/// </summary>
		public int pid
		{
			set{ _pid=value;}
			get{return _pid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? classid
		{
			set{ _classid=value;}
			get{return _classid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? classxid
		{
			set{ _classxid=value;}
			get{return _classxid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string productname
		{
			set{ _productname=value;}
			get{return _productname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string productintroduce
		{
			set{ _productintroduce=value;}
			get{return _productintroduce;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string productchu
		{
			set{ _productchu=value;}
			get{return _productchu;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string productimage
		{
			set{ _productimage=value;}
			get{return _productimage;}
		}
		/// <summary>
		/// 
		/// </summary>
		public decimal? masterprice
		{
			set{ _masterprice=value;}
			get{return _masterprice;}
		}
		/// <summary>
		/// 
		/// </summary>
		public decimal? hotprice
		{
			set{ _hotprice=value;}
			get{return _hotprice;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int newproduct
		{
			set{ _newproduct=value;}
			get{return _newproduct;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string guige
		{
			set{ _guige=value;}
			get{return _guige;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string productguanjian
		{
			set{ _productguanjian=value;}
			get{return _productguanjian;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? adddate
		{
			set{ _adddate=value;}
			get{return _adddate;}
		}
		/// <summary>
		/// ���
		/// </summary>
		public int? pkc
		{
			set{ _pkc=value;}
			get{return _pkc;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? sl
		{
			set{ _sl=value;}
			get{return _sl;}
		}
		/// <summary>
		/// �������
		/// </summary>
		public int? hittimes
		{
			set{ _hittimes=value;}
			get{return _hittimes;}
		}
		/// <summary>
		/// ����
		/// </summary>
		public int? jifen
		{
			set{ _jifen=value;}
			get{return _jifen;}
		}
		/// <summary>
		/// ��Ʒ
		/// </summary>
		public string zenpin
		{
			set{ _zenpin=value;}
			get{return _zenpin;}
		}
		#endregion Model

	}
}

