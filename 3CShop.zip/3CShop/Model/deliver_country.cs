using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����deliver_country ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class deliver_country
	{
		public deliver_country()
		{}
		#region Model
		private int _deliver_country_id;
		private string _deliver_country_name;
		private int? _zone_id;
		/// <summary>
		/// 
		/// </summary>
		public int deliver_country_id
		{
			set{ _deliver_country_id=value;}
			get{return _deliver_country_id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string deliver_country_name
		{
			set{ _deliver_country_name=value;}
			get{return _deliver_country_name;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? zone_id
		{
			set{ _zone_id=value;}
			get{return _zone_id;}
		}
		#endregion Model

	}
}

