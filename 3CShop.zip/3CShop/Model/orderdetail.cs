using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����orderdetail ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class orderdetail
	{
		public orderdetail()
		{}
		#region Model
		private int _detailid;
		private int? _pid;
		private int? _shuliang;
		private string _orderid;
		private decimal? _producttotail;
		/// <summary>
		/// 
		/// </summary>
		public int detailid
		{
			set{ _detailid=value;}
			get{return _detailid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? pid
		{
			set{ _pid=value;}
			get{return _pid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? shuliang
		{
			set{ _shuliang=value;}
			get{return _shuliang;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string orderid
		{
			set{ _orderid=value;}
			get{return _orderid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public decimal? producttotail
		{
			set{ _producttotail=value;}
			get{return _producttotail;}
		}
		#endregion Model

	}
}

