using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����help2 ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class help2
	{
		public help2()
		{}
		#region Model
		private int _hhid;
		private int? _hid;
		private string _helpname;
		private string _helpdetail;
		/// <summary>
		/// 
		/// </summary>
		public int hhid
		{
			set{ _hhid=value;}
			get{return _hhid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? hid
		{
			set{ _hid=value;}
			get{return _hid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string helpname
		{
			set{ _helpname=value;}
			get{return _helpname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string helpdetail
		{
			set{ _helpdetail=value;}
			get{return _helpdetail;}
		}
		#endregion Model

	}
}

