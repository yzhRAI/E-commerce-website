using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����city_table ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class city_table
	{
		public city_table()
		{}
		#region Model
		private int _id;
		private int? _oneid;
		private int? _twoid;
		private int? _three;
		private string _name;
		/// <summary>
		/// 
		/// </summary>
		public int id
		{
			set{ _id=value;}
			get{return _id;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? oneid
		{
			set{ _oneid=value;}
			get{return _oneid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? twoid
		{
			set{ _twoid=value;}
			get{return _twoid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? three
		{
			set{ _three=value;}
			get{return _three;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string name
		{
			set{ _name=value;}
			get{return _name;}
		}
		#endregion Model

	}
}

