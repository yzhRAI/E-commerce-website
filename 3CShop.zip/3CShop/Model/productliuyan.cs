using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����productliuyan ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class productliuyan
	{
		public productliuyan()
		{}
		#region Model
		private int _lid;
		private int? _pid;
		private string _liuname;
		private DateTime? _liutime;
		private string _liuzhu;
		private string _liuhui;
		private string _huifutime;
		/// <summary>
		/// 
		/// </summary>
		public int lid
		{
			set{ _lid=value;}
			get{return _lid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? pid
		{
			set{ _pid=value;}
			get{return _pid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string liuname
		{
			set{ _liuname=value;}
			get{return _liuname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? liutime
		{
			set{ _liutime=value;}
			get{return _liutime;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string liuzhu
		{
			set{ _liuzhu=value;}
			get{return _liuzhu;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string liuhui
		{
			set{ _liuhui=value;}
			get{return _liuhui;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string huifutime
		{
			set{ _huifutime=value;}
			get{return _huifutime;}
		}
		#endregion Model

	}
}

