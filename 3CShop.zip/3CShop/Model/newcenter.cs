using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����newcenter ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class newcenter
	{
		public newcenter()
		{}
		#region Model
		private int _nid;
		private string _newtitle;
		private string _newcontact;
		private DateTime? _newshijian;
		private int? _hittime;
		/// <summary>
		/// 
		/// </summary>
		public int nid
		{
			set{ _nid=value;}
			get{return _nid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string newtitle
		{
			set{ _newtitle=value;}
			get{return _newtitle;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string newcontact
		{
			set{ _newcontact=value;}
			get{return _newcontact;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? newshijian
		{
			set{ _newshijian=value;}
			get{return _newshijian;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? hittime
		{
			set{ _hittime=value;}
			get{return _hittime;}
		}
		#endregion Model

	}
}

