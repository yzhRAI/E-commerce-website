using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����pxiaoxi ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class pxiaoxi
	{
		public pxiaoxi()
		{}
		#region Model
		private int _pid;
		private string _pcontent;
		private string _pfeel;
		private string _userid;
		/// <summary>
		/// 
		/// </summary>
		public int pid
		{
			set{ _pid=value;}
			get{return _pid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string pcontent
		{
			set{ _pcontent=value;}
			get{return _pcontent;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string pfeel
		{
			set{ _pfeel=value;}
			get{return _pfeel;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string userid
		{
			set{ _userid=value;}
			get{return _userid;}
		}
		#endregion Model

	}
}

