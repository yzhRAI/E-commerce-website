using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����shoucang ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class shoucang
	{
		public shoucang()
		{}
		#region Model
		private int _sid;
		private int? _pid;
		private string _username;
		private DateTime? _shoutime;
		/// <summary>
		/// 
		/// </summary>
		public int sid
		{
			set{ _sid=value;}
			get{return _sid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? pid
		{
			set{ _pid=value;}
			get{return _pid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string username
		{
			set{ _username=value;}
			get{return _username;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? shoutime
		{
			set{ _shoutime=value;}
			get{return _shoutime;}
		}
		#endregion Model

	}
}

