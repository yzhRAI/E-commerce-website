using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����gonggao ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class gonggao
	{
		public gonggao()
		{}
		#region Model
		private int _gid;
		private string _gtitle;
		private string _gcontent;
		private DateTime? _gdate;
		private int? _gfeel;
		/// <summary>
		/// 
		/// </summary>
		public int gid
		{
			set{ _gid=value;}
			get{return _gid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string gtitle
		{
			set{ _gtitle=value;}
			get{return _gtitle;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string gcontent
		{
			set{ _gcontent=value;}
			get{return _gcontent;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? gdate
		{
			set{ _gdate=value;}
			get{return _gdate;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? gfeel
		{
			set{ _gfeel=value;}
			get{return _gfeel;}
		}
		#endregion Model

	}
}

