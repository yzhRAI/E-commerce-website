using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����leibie ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class leibie
	{
		public leibie()
		{}
		#region Model
		private int _classid;
		private string _classname;
		/// <summary>
		/// 
		/// </summary>
		public int Classid
		{
			set{ _classid=value;}
			get{return _classid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Classname
		{
			set{ _classname=value;}
			get{return _classname;}
		}
		#endregion Model

	}
}

