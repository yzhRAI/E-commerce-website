using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����orders ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class orders
	{
		public orders()
		{}
		#region Model
		private int _oid;
		private string _orderid;
		private string _username;
		private int? _userid;
		private string _shouhuoname;
		private string _address;
		private string _postcode;
		private string _telephone;
		private string _songhuofs;
		private string _fukuanfs;
		private int? _dingdanfeel;
		private DateTime? _dingdanshijian;
		private decimal? _dingdantotal;
		private string _beizhu;
		private int? _djifen;
		/// <summary>
		/// 
		/// </summary>
		public int oid
		{
			set{ _oid=value;}
			get{return _oid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string orderid
		{
			set{ _orderid=value;}
			get{return _orderid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string username
		{
			set{ _username=value;}
			get{return _username;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? userid
		{
			set{ _userid=value;}
			get{return _userid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string shouhuoname
		{
			set{ _shouhuoname=value;}
			get{return _shouhuoname;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string address
		{
			set{ _address=value;}
			get{return _address;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string postcode
		{
			set{ _postcode=value;}
			get{return _postcode;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string telephone
		{
			set{ _telephone=value;}
			get{return _telephone;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string songhuofs
		{
			set{ _songhuofs=value;}
			get{return _songhuofs;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string fukuanfs
		{
			set{ _fukuanfs=value;}
			get{return _fukuanfs;}
		}
		/// <summary>
		/// ����״̬ 0,ȡ������ 1,�ȴ����� 2,�̼��ѷ��� 3,ȷ���ջ� 4,��ɽ���
		/// </summary>
		public int? dingdanfeel
		{
			set{ _dingdanfeel=value;}
			get{return _dingdanfeel;}
		}
		/// <summary>
		/// 
		/// </summary>
		public DateTime? dingdanshijian
		{
			set{ _dingdanshijian=value;}
			get{return _dingdanshijian;}
		}
		/// <summary>
		/// 
		/// </summary>
		public decimal? dingdantotal
		{
			set{ _dingdantotal=value;}
			get{return _dingdantotal;}
		}
		/// <summary>
		/// ��ע��Ϣ
		/// </summary>
		public string beizhu
		{
			set{ _beizhu=value;}
			get{return _beizhu;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? djifen
		{
			set{ _djifen=value;}
			get{return _djifen;}
		}
		#endregion Model

	}
}

