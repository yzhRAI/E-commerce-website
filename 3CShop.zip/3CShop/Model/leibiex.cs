using System;
namespace CAI.SHOP.Model
{
	/// <summary>
	/// ʵ����leibiex ��(����˵���Զ���ȡ���ݿ��ֶε�������Ϣ)
	/// </summary>
	[Serializable]
	public class leibiex
	{
		public leibiex()
		{}
		#region Model
		private int _classxid;
		private int? _classid;
		private string _classxname;
		/// <summary>
		/// 
		/// </summary>
		public int Classxid
		{
			set{ _classxid=value;}
			get{return _classxid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public int? Classid
		{
			set{ _classid=value;}
			get{return _classid;}
		}
		/// <summary>
		/// 
		/// </summary>
		public string Classxname
		{
			set{ _classxname=value;}
			get{return _classxname;}
		}
		#endregion Model

	}
}

