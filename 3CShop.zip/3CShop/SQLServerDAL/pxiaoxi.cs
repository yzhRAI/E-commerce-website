using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����pxiaoxi��
	/// </summary>
	public class pxiaoxi:Ipxiaoxi
	{
		public pxiaoxi()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("pid", "pxiaoxi"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int pid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from pxiaoxi");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}

        public int dscount(string username)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(*) from pxiaoxi where userid='" + username + "'and pfeel=0");
           
            return DbHelperSQL.ExecuteSqlScarlar(strSql.ToString());
        
        
        }

		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.pxiaoxi model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into pxiaoxi(");
			strSql.Append("pcontent,pfeel,userid)");
			strSql.Append(" values (");
			strSql.Append("@pcontent,@pfeel,@userid)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@pcontent", SqlDbType.Text),
					new SqlParameter("@pfeel", SqlDbType.VarChar,50),
					new SqlParameter("@userid", SqlDbType.VarChar,50)};
			parameters[0].Value = model.pcontent;
			parameters[1].Value = model.pfeel;
			parameters[2].Value = model.userid;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.pxiaoxi model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update pxiaoxi set ");
			strSql.Append("pcontent=@pcontent,");
			strSql.Append("pfeel=@pfeel,");
			strSql.Append("userid=@userid");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@pcontent", SqlDbType.Text),
					new SqlParameter("@pfeel", SqlDbType.VarChar,50),
					new SqlParameter("@userid", SqlDbType.VarChar,50)};
			parameters[0].Value = model.pid;
			parameters[1].Value = model.pcontent;
			parameters[2].Value = model.pfeel;
			parameters[3].Value = model.userid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int pid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from pxiaoxi ");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.pxiaoxi GetModel(int pid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 pid,pcontent,pfeel,userid from pxiaoxi ");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			CAI.SHOP.Model.pxiaoxi model=new CAI.SHOP.Model.pxiaoxi();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["pid"].ToString()!="")
				{
					model.pid=int.Parse(ds.Tables[0].Rows[0]["pid"].ToString());
				}
				model.pcontent=ds.Tables[0].Rows[0]["pcontent"].ToString();
				model.pfeel=ds.Tables[0].Rows[0]["pfeel"].ToString();
				model.userid=ds.Tables[0].Rows[0]["userid"].ToString();
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select pid,pcontent,pfeel,userid ");
			strSql.Append(" FROM pxiaoxi ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" pid,pcontent,pfeel,userid ");
			strSql.Append(" FROM pxiaoxi ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "pxiaoxi";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

