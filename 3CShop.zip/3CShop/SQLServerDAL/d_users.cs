using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����d_users��
	/// </summary>
	public class d_users:Id_users
	{
		public d_users()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("uid", "d_users"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int uid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from d_users");
			strSql.Append(" where uid=@uid ");
			SqlParameter[] parameters = {
					new SqlParameter("@uid", SqlDbType.Int,4)};
			parameters[0].Value = uid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}

        public bool Exists(string username, string password)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(*) from d_users ");
            strSql.Append("where username=@username and password=@password");
            SqlParameter[] parameters ={
                                        new SqlParameter("@username", SqlDbType.NVarChar,50),
					
					                    new SqlParameter("@password", SqlDbType.NVarChar,50)};
            parameters[0].Value = username;
            parameters[1].Value = password;
           return  DbHelperSQL.Exists(strSql.ToString(), parameters);

        
        
        }

        /// <summary>
        /// �Ƿ���ڸü�¼
        /// </summary>
        public bool Exists(string username)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(*) from d_users");
            strSql.Append(" where username=@username ");
            SqlParameter[] parameters = {
					new SqlParameter("@username",SqlDbType.NVarChar,50)};
            parameters[0].Value = username;

            return DbHelperSQL.Exists(strSql.ToString(), parameters);
        }
        

		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.d_users model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into d_users(");
			strSql.Append("username,truename,password,question,answer,email,sex,regdate,lastloginip,logintimes,userjifen,QQ,lastlogintime,IDCARD,Address,Telephone,Postcode,Usertype)");
			strSql.Append(" values (");
			strSql.Append("@username,@truename,@password,@question,@answer,@email,@sex,@regdate,@lastloginip,@logintimes,@userjifen,@QQ,@lastlogintime,@IDCARD,@Address,@Telephone,@Postcode,@Usertype)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@username", SqlDbType.NVarChar,50),
					new SqlParameter("@truename", SqlDbType.NVarChar,50),
					new SqlParameter("@password", SqlDbType.NVarChar,50),
					new SqlParameter("@question", SqlDbType.NVarChar,50),
					new SqlParameter("@answer", SqlDbType.NVarChar,50),
					new SqlParameter("@email", SqlDbType.NVarChar,50),
					new SqlParameter("@sex", SqlDbType.NVarChar,50),
					new SqlParameter("@regdate", SqlDbType.DateTime),
					new SqlParameter("@lastloginip", SqlDbType.NVarChar,50),
					new SqlParameter("@logintimes", SqlDbType.Int,4),
					new SqlParameter("@userjifen", SqlDbType.Int,4),
					new SqlParameter("@QQ", SqlDbType.NVarChar,50),
					new SqlParameter("@lastlogintime", SqlDbType.DateTime),
					new SqlParameter("@IDCARD", SqlDbType.NVarChar,50),
					new SqlParameter("@Address", SqlDbType.NVarChar,200),
					new SqlParameter("@Telephone", SqlDbType.NVarChar,50),
					new SqlParameter("@Postcode", SqlDbType.NVarChar,50),
					new SqlParameter("@Usertype", SqlDbType.Int,4)};
			parameters[0].Value = model.username;
			parameters[1].Value = model.truename;
			parameters[2].Value = model.password;
			parameters[3].Value = model.question;
			parameters[4].Value = model.answer;
			parameters[5].Value = model.email;
			parameters[6].Value = model.sex;
			parameters[7].Value = model.regdate;
			parameters[8].Value = model.lastloginip;
			parameters[9].Value = model.logintimes;
			parameters[10].Value = model.userjifen;
			parameters[11].Value = model.QQ;
			parameters[12].Value = model.lastlogintime;
			parameters[13].Value = model.IDCARD;
			parameters[14].Value = model.Address;
			parameters[15].Value = model.Telephone;
			parameters[16].Value = model.Postcode;
			parameters[17].Value = model.Usertype;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public int Update(CAI.SHOP.Model.d_users model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update d_users set ");
			strSql.Append("username=@username,");
			strSql.Append("truename=@truename,");
			strSql.Append("password=@password,");
			strSql.Append("question=@question,");
			strSql.Append("answer=@answer,");
			strSql.Append("email=@email,");
			strSql.Append("sex=@sex,");
			strSql.Append("regdate=@regdate,");
			strSql.Append("lastloginip=@lastloginip,");
			strSql.Append("logintimes=@logintimes,");
			strSql.Append("userjifen=@userjifen,");
			strSql.Append("QQ=@QQ,");
			strSql.Append("lastlogintime=@lastlogintime,");
			strSql.Append("IDCARD=@IDCARD,");
			strSql.Append("Address=@Address,");
			strSql.Append("Telephone=@Telephone,");
			strSql.Append("Postcode=@Postcode,");
			strSql.Append("Usertype=@Usertype");
			strSql.Append(" where uid=@uid ");
			SqlParameter[] parameters = {
					new SqlParameter("@uid", SqlDbType.Int,4),
					new SqlParameter("@username", SqlDbType.NVarChar,50),
					new SqlParameter("@truename", SqlDbType.NVarChar,50),
					new SqlParameter("@password", SqlDbType.NVarChar,50),
					new SqlParameter("@question", SqlDbType.NVarChar,50),
					new SqlParameter("@answer", SqlDbType.NVarChar,50),
					new SqlParameter("@email", SqlDbType.NVarChar,50),
					new SqlParameter("@sex", SqlDbType.NVarChar,50),
					new SqlParameter("@regdate", SqlDbType.DateTime),
					new SqlParameter("@lastloginip", SqlDbType.NVarChar,50),
					new SqlParameter("@logintimes", SqlDbType.Int,4),
					new SqlParameter("@userjifen", SqlDbType.Int,4),
					new SqlParameter("@QQ", SqlDbType.NVarChar,50),
					new SqlParameter("@lastlogintime", SqlDbType.DateTime),
					new SqlParameter("@IDCARD", SqlDbType.NVarChar,50),
					new SqlParameter("@Address", SqlDbType.NVarChar,200),
					new SqlParameter("@Telephone", SqlDbType.NVarChar,50),
					new SqlParameter("@Postcode", SqlDbType.NVarChar,50),
					new SqlParameter("@Usertype", SqlDbType.Int,4)};
			parameters[0].Value = model.uid;
			parameters[1].Value = model.username;
			parameters[2].Value = model.truename;
			parameters[3].Value = model.password;
			parameters[4].Value = model.question;
			parameters[5].Value = model.answer;
			parameters[6].Value = model.email;
			parameters[7].Value = model.sex;
			parameters[8].Value = model.regdate;
			parameters[9].Value = model.lastloginip;
			parameters[10].Value = model.logintimes;
			parameters[11].Value = model.userjifen;
			parameters[12].Value = model.QQ;
			parameters[13].Value = model.lastlogintime;
			parameters[14].Value = model.IDCARD;
			parameters[15].Value = model.Address;
			parameters[16].Value = model.Telephone;
			parameters[17].Value = model.Postcode;
			parameters[18].Value = model.Usertype;

		return	DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int uid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from d_users ");
			strSql.Append(" where uid=@uid ");
			SqlParameter[] parameters = {
					new SqlParameter("@uid", SqlDbType.Int,4)};
			parameters[0].Value = uid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.d_users GetModel(int uid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 uid,username,truename,password,question,answer,email,sex,regdate,lastloginip,logintimes,userjifen,QQ,lastlogintime,IDCARD,Address,Telephone,Postcode,Usertype from d_users ");
			strSql.Append(" where uid=@uid ");
			SqlParameter[] parameters = {
					new SqlParameter("@uid", SqlDbType.Int,4)};
			parameters[0].Value = uid;

			CAI.SHOP.Model.d_users model=new CAI.SHOP.Model.d_users();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["uid"].ToString()!="")
				{
					model.uid=int.Parse(ds.Tables[0].Rows[0]["uid"].ToString());
				}
				model.username=ds.Tables[0].Rows[0]["username"].ToString();
				model.truename=ds.Tables[0].Rows[0]["truename"].ToString();
				model.password=ds.Tables[0].Rows[0]["password"].ToString();
				model.question=ds.Tables[0].Rows[0]["question"].ToString();
				model.answer=ds.Tables[0].Rows[0]["answer"].ToString();
				model.email=ds.Tables[0].Rows[0]["email"].ToString();
				model.sex=ds.Tables[0].Rows[0]["sex"].ToString();
				if(ds.Tables[0].Rows[0]["regdate"].ToString()!="")
				{
					model.regdate=DateTime.Parse(ds.Tables[0].Rows[0]["regdate"].ToString());
				}
				model.lastloginip=ds.Tables[0].Rows[0]["lastloginip"].ToString();
				if(ds.Tables[0].Rows[0]["logintimes"].ToString()!="")
				{
					model.logintimes=int.Parse(ds.Tables[0].Rows[0]["logintimes"].ToString());
				}
				if(ds.Tables[0].Rows[0]["userjifen"].ToString()!="")
				{
					model.userjifen=int.Parse(ds.Tables[0].Rows[0]["userjifen"].ToString());
				}
				model.QQ=ds.Tables[0].Rows[0]["QQ"].ToString();
				if(ds.Tables[0].Rows[0]["lastlogintime"].ToString()!="")
				{
					model.lastlogintime=DateTime.Parse(ds.Tables[0].Rows[0]["lastlogintime"].ToString());
				}
				model.IDCARD=ds.Tables[0].Rows[0]["IDCARD"].ToString();
				model.Address=ds.Tables[0].Rows[0]["Address"].ToString();
				model.Telephone=ds.Tables[0].Rows[0]["Telephone"].ToString();
				model.Postcode=ds.Tables[0].Rows[0]["Postcode"].ToString();
				if(ds.Tables[0].Rows[0]["Usertype"].ToString()!="")
				{
					model.Usertype=int.Parse(ds.Tables[0].Rows[0]["Usertype"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select uid,username,truename,password,question,answer,email,sex,regdate,lastloginip,logintimes,userjifen,QQ,lastlogintime,IDCARD,Address,Telephone,Postcode,Usertype ");
			strSql.Append(" FROM d_users ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" uid,username,truename,password,question,answer,email,sex,regdate,lastloginip,logintimes,userjifen,QQ,lastlogintime,IDCARD,Address,Telephone,Postcode,Usertype ");
			strSql.Append(" FROM d_users ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "d_users";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

