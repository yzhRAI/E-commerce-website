using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����gonggao��
	/// </summary>
	public class gonggao:Igonggao
	{
		public gonggao()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("gid", "gonggao"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int gid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from gonggao");
			strSql.Append(" where gid=@gid ");
			SqlParameter[] parameters = {
					new SqlParameter("@gid", SqlDbType.Int,4)};
			parameters[0].Value = gid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.gonggao model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into gonggao(");
			strSql.Append("gtitle,gcontent,gdate,gfeel)");
			strSql.Append(" values (");
			strSql.Append("@gtitle,@gcontent,@gdate,@gfeel)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@gtitle", SqlDbType.VarChar,50),
					new SqlParameter("@gcontent", SqlDbType.Text),
					new SqlParameter("@gdate", SqlDbType.DateTime),
					new SqlParameter("@gfeel", SqlDbType.Int,4)};
			parameters[0].Value = model.gtitle;
			parameters[1].Value = model.gcontent;
			parameters[2].Value = model.gdate;
			parameters[3].Value = model.gfeel;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.gonggao model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update gonggao set ");
			strSql.Append("gtitle=@gtitle,");
			strSql.Append("gcontent=@gcontent,");
			strSql.Append("gdate=@gdate,");
			strSql.Append("gfeel=@gfeel");
			strSql.Append(" where gid=@gid ");
			SqlParameter[] parameters = {
					new SqlParameter("@gid", SqlDbType.Int,4),
					new SqlParameter("@gtitle", SqlDbType.VarChar,50),
					new SqlParameter("@gcontent", SqlDbType.Text),
					new SqlParameter("@gdate", SqlDbType.DateTime),
					new SqlParameter("@gfeel", SqlDbType.Int,4)};
			parameters[0].Value = model.gid;
			parameters[1].Value = model.gtitle;
			parameters[2].Value = model.gcontent;
			parameters[3].Value = model.gdate;
			parameters[4].Value = model.gfeel;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int gid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from gonggao ");
			strSql.Append(" where gid=@gid ");
			SqlParameter[] parameters = {
					new SqlParameter("@gid", SqlDbType.Int,4)};
			parameters[0].Value = gid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.gonggao GetModel(int gid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 gid,gtitle,gcontent,gdate,gfeel from gonggao ");
			strSql.Append(" where gid=@gid ");
			SqlParameter[] parameters = {
					new SqlParameter("@gid", SqlDbType.Int,4)};
			parameters[0].Value = gid;

			CAI.SHOP.Model.gonggao model=new CAI.SHOP.Model.gonggao();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["gid"].ToString()!="")
				{
					model.gid=int.Parse(ds.Tables[0].Rows[0]["gid"].ToString());
				}
				model.gtitle=ds.Tables[0].Rows[0]["gtitle"].ToString();
				model.gcontent=ds.Tables[0].Rows[0]["gcontent"].ToString();
				if(ds.Tables[0].Rows[0]["gdate"].ToString()!="")
				{
					model.gdate=DateTime.Parse(ds.Tables[0].Rows[0]["gdate"].ToString());
				}
				if(ds.Tables[0].Rows[0]["gfeel"].ToString()!="")
				{
					model.gfeel=int.Parse(ds.Tables[0].Rows[0]["gfeel"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select gid,gtitle,gcontent,gdate,gfeel ");
			strSql.Append(" FROM gonggao ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" gid,gtitle,gcontent,gdate,gfeel ");
			strSql.Append(" FROM gonggao ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "gonggao";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

