using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����product��
	/// </summary>
	public class product:Iproduct
	{
		public product()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("pid", "product"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int pid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from product");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.product model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into product(");
			strSql.Append("classid,classxid,productname,productintroduce,productchu,productimage,masterprice,hotprice,newproduct,guige,productguanjian,adddate,pkc,sl,hittimes,jifen,zenpin)");
			strSql.Append(" values (");
			strSql.Append("@classid,@classxid,@productname,@productintroduce,@productchu,@productimage,@masterprice,@hotprice,@newproduct,@guige,@productguanjian,@adddate,@pkc,@sl,@hittimes,@jifen,@zenpin)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@classid", SqlDbType.Int,4),
					new SqlParameter("@classxid", SqlDbType.Int,4),
					new SqlParameter("@productname", SqlDbType.NVarChar,50),
					new SqlParameter("@productintroduce", SqlDbType.Text),
					new SqlParameter("@productchu", SqlDbType.NVarChar,200),
					new SqlParameter("@productimage", SqlDbType.NVarChar,50),
					new SqlParameter("@masterprice", SqlDbType.Decimal,9),
					new SqlParameter("@hotprice", SqlDbType.Decimal,9),
					new SqlParameter("@newproduct", SqlDbType.Int,4),
					new SqlParameter("@guige", SqlDbType.NVarChar,50),
					new SqlParameter("@productguanjian", SqlDbType.NVarChar,200),
					new SqlParameter("@adddate", SqlDbType.DateTime),
					new SqlParameter("@pkc", SqlDbType.Int,4),
					new SqlParameter("@sl", SqlDbType.Int,4),
					new SqlParameter("@hittimes", SqlDbType.Int,4),
					new SqlParameter("@jifen", SqlDbType.Int,4),
					new SqlParameter("@zenpin", SqlDbType.NVarChar,50)};
			parameters[0].Value = model.classid;
			parameters[1].Value = model.classxid;
			parameters[2].Value = model.productname;
			parameters[3].Value = model.productintroduce;
			parameters[4].Value = model.productchu;
			parameters[5].Value = model.productimage;
			parameters[6].Value = model.masterprice;
			parameters[7].Value = model.hotprice;
			parameters[8].Value = model.newproduct;
			parameters[9].Value = model.guige;
			parameters[10].Value = model.productguanjian;
			parameters[11].Value = model.adddate;
			parameters[12].Value = model.pkc;
			parameters[13].Value = model.sl;
			parameters[14].Value = model.hittimes;
			parameters[15].Value = model.jifen;
			parameters[16].Value = model.zenpin;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.product model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update product set ");
			strSql.Append("classid=@classid,");
			strSql.Append("classxid=@classxid,");
			strSql.Append("productname=@productname,");
			strSql.Append("productintroduce=@productintroduce,");
			strSql.Append("productchu=@productchu,");
			strSql.Append("productimage=@productimage,");
			strSql.Append("masterprice=@masterprice,");
			strSql.Append("hotprice=@hotprice,");
			strSql.Append("newproduct=@newproduct,");
			strSql.Append("guige=@guige,");
			strSql.Append("productguanjian=@productguanjian,");
			strSql.Append("adddate=@adddate,");
			strSql.Append("pkc=@pkc,");
			strSql.Append("sl=@sl,");
			strSql.Append("hittimes=@hittimes,");
			strSql.Append("jifen=@jifen,");
			strSql.Append("zenpin=@zenpin");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@classid", SqlDbType.Int,4),
					new SqlParameter("@classxid", SqlDbType.Int,4),
					new SqlParameter("@productname", SqlDbType.NVarChar,50),
					new SqlParameter("@productintroduce", SqlDbType.Text),
					new SqlParameter("@productchu", SqlDbType.NVarChar,200),
					new SqlParameter("@productimage", SqlDbType.NVarChar,50),
					new SqlParameter("@masterprice", SqlDbType.Decimal,9),
					new SqlParameter("@hotprice", SqlDbType.Decimal,9),
					new SqlParameter("@newproduct", SqlDbType.Int,4),
					new SqlParameter("@guige", SqlDbType.NVarChar,50),
					new SqlParameter("@productguanjian", SqlDbType.NVarChar,200),
					new SqlParameter("@adddate", SqlDbType.DateTime),
					new SqlParameter("@pkc", SqlDbType.Int,4),
					new SqlParameter("@sl", SqlDbType.Int,4),
					new SqlParameter("@hittimes", SqlDbType.Int,4),
					new SqlParameter("@jifen", SqlDbType.Int,4),
					new SqlParameter("@zenpin", SqlDbType.NVarChar,50)};
			parameters[0].Value = model.pid;
			parameters[1].Value = model.classid;
			parameters[2].Value = model.classxid;
			parameters[3].Value = model.productname;
			parameters[4].Value = model.productintroduce;
			parameters[5].Value = model.productchu;
			parameters[6].Value = model.productimage;
			parameters[7].Value = model.masterprice;
			parameters[8].Value = model.hotprice;
			parameters[9].Value = model.newproduct;
			parameters[10].Value = model.guige;
			parameters[11].Value = model.productguanjian;
			parameters[12].Value = model.adddate;
			parameters[13].Value = model.pkc;
			parameters[14].Value = model.sl;
			parameters[15].Value = model.hittimes;
			parameters[16].Value = model.jifen;
			parameters[17].Value = model.zenpin;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int pid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from product ");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.product GetModel(int pid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 pid,classid,classxid,productname,productintroduce,productchu,productimage,masterprice,hotprice,newproduct,guige,productguanjian,adddate,pkc,sl,hittimes,jifen,zenpin from product ");
			strSql.Append(" where pid=@pid ");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4)};
			parameters[0].Value = pid;

			CAI.SHOP.Model.product model=new CAI.SHOP.Model.product();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["pid"].ToString()!="")
				{
					model.pid=int.Parse(ds.Tables[0].Rows[0]["pid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["classid"].ToString()!="")
				{
					model.classid=int.Parse(ds.Tables[0].Rows[0]["classid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["classxid"].ToString()!="")
				{
					model.classxid=int.Parse(ds.Tables[0].Rows[0]["classxid"].ToString());
				}
				model.productname=ds.Tables[0].Rows[0]["productname"].ToString();
				model.productintroduce=ds.Tables[0].Rows[0]["productintroduce"].ToString();
				model.productchu=ds.Tables[0].Rows[0]["productchu"].ToString();
				model.productimage=ds.Tables[0].Rows[0]["productimage"].ToString();
				if(ds.Tables[0].Rows[0]["masterprice"].ToString()!="")
				{
					model.masterprice=decimal.Parse(ds.Tables[0].Rows[0]["masterprice"].ToString());
				}
				if(ds.Tables[0].Rows[0]["hotprice"].ToString()!="")
				{
					model.hotprice=decimal.Parse(ds.Tables[0].Rows[0]["hotprice"].ToString());
				}
				if(ds.Tables[0].Rows[0]["newproduct"].ToString()!="")
				{
					model.newproduct=int.Parse(ds.Tables[0].Rows[0]["newproduct"].ToString());
				}
				model.guige=ds.Tables[0].Rows[0]["guige"].ToString();
				model.productguanjian=ds.Tables[0].Rows[0]["productguanjian"].ToString();
				if(ds.Tables[0].Rows[0]["adddate"].ToString()!="")
				{
					model.adddate=DateTime.Parse(ds.Tables[0].Rows[0]["adddate"].ToString());
				}
				if(ds.Tables[0].Rows[0]["pkc"].ToString()!="")
				{
					model.pkc=int.Parse(ds.Tables[0].Rows[0]["pkc"].ToString());
				}
				if(ds.Tables[0].Rows[0]["sl"].ToString()!="")
				{
					model.sl=int.Parse(ds.Tables[0].Rows[0]["sl"].ToString());
				}
				if(ds.Tables[0].Rows[0]["hittimes"].ToString()!="")
				{
					model.hittimes=int.Parse(ds.Tables[0].Rows[0]["hittimes"].ToString());
				}
				if(ds.Tables[0].Rows[0]["jifen"].ToString()!="")
				{
					model.jifen=int.Parse(ds.Tables[0].Rows[0]["jifen"].ToString());
				}
				model.zenpin=ds.Tables[0].Rows[0]["zenpin"].ToString();
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
            strSql.Append("select pid,classid,classxid,productname,productintroduce,productchu,productimage,masterprice,hotprice,newproduct,guige,productguanjian,adddate,pkc,sl,hittimes,jifen,zenpin,Classname,Classxname ");
            strSql.Append(" FROM V_Product ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

        public DataSet GetTwoList(string orderid)
        {
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select orderdetail.*,product.* from orderdetail,product where orderdetail.orderid='" +orderid+ "'and product.pid=orderdetail.pid ");
            return DbHelperSQL.Query(strSql.ToString());
        
        }

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
            strSql.Append(" pid,classid,classxid,productname,productintroduce,productchu,productimage,masterprice,hotprice,newproduct,guige,productguanjian,adddate,pkc,sl,hittimes,jifen,zenpin,Classname,Classxname ");
            strSql.Append(" FROM V_Product ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "product";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

