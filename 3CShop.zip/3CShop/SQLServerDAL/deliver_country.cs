using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����deliver_country��
	/// </summary>
	public class deliver_country:Ideliver_country
	{
		public deliver_country()
		{}
		#region  ��Ա����



		/// <summary>
		/// ����һ������
		/// </summary>
		public void Add(CAI.SHOP.Model.deliver_country model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into deliver_country(");
			strSql.Append("deliver_country_id,deliver_country_name,zone_id)");
			strSql.Append(" values (");
			strSql.Append("@deliver_country_id,@deliver_country_name,@zone_id)");
			SqlParameter[] parameters = {
					new SqlParameter("@deliver_country_id", SqlDbType.Int,4),
					new SqlParameter("@deliver_country_name", SqlDbType.NVarChar,1000),
					new SqlParameter("@zone_id", SqlDbType.Int,4)};
			parameters[0].Value = model.deliver_country_id;
			parameters[1].Value = model.deliver_country_name;
			parameters[2].Value = model.zone_id;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.deliver_country model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update deliver_country set ");
			strSql.Append("deliver_country_id=@deliver_country_id,");
			strSql.Append("deliver_country_name=@deliver_country_name,");
			strSql.Append("zone_id=@zone_id");
			strSql.Append(" where ");
			SqlParameter[] parameters = {
					new SqlParameter("@deliver_country_id", SqlDbType.Int,4),
					new SqlParameter("@deliver_country_name", SqlDbType.NVarChar,1000),
					new SqlParameter("@zone_id", SqlDbType.Int,4)};
			parameters[0].Value = model.deliver_country_id;
			parameters[1].Value = model.deliver_country_name;
			parameters[2].Value = model.zone_id;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete()
		{
			//�ñ���������Ϣ�����Զ�������/�����ֶ�
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from deliver_country ");
			strSql.Append(" where ");
			SqlParameter[] parameters = {
};

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.deliver_country GetModel()
		{
			//�ñ���������Ϣ�����Զ�������/�����ֶ�
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 deliver_country_id,deliver_country_name,zone_id from deliver_country ");
			strSql.Append(" where ");
			SqlParameter[] parameters = {
};

			CAI.SHOP.Model.deliver_country model=new CAI.SHOP.Model.deliver_country();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["deliver_country_id"].ToString()!="")
				{
					model.deliver_country_id=int.Parse(ds.Tables[0].Rows[0]["deliver_country_id"].ToString());
				}
				model.deliver_country_name=ds.Tables[0].Rows[0]["deliver_country_name"].ToString();
				if(ds.Tables[0].Rows[0]["zone_id"].ToString()!="")
				{
					model.zone_id=int.Parse(ds.Tables[0].Rows[0]["zone_id"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select deliver_country_id,deliver_country_name,zone_id ");
			strSql.Append(" FROM deliver_country ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" deliver_country_id,deliver_country_name,zone_id ");
			strSql.Append(" FROM deliver_country ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "deliver_country";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

