using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����shoucang��
	/// </summary>
	public class shoucang:Ishoucang
	{
		public shoucang()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("sid", "shoucang"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int sid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from shoucang");
			strSql.Append(" where sid=@sid ");
			SqlParameter[] parameters = {
					new SqlParameter("@sid", SqlDbType.Int,4)};
			parameters[0].Value = sid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.shoucang model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into shoucang(");
			strSql.Append("pid,username,shoutime)");
			strSql.Append(" values (");
			strSql.Append("@pid,@username,@shoutime)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@username", SqlDbType.VarChar,50),
					new SqlParameter("@shoutime", SqlDbType.DateTime)};
			parameters[0].Value = model.pid;
			parameters[1].Value = model.username;
			parameters[2].Value = model.shoutime;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.shoucang model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update shoucang set ");
			strSql.Append("pid=@pid,");
			strSql.Append("username=@username,");
			strSql.Append("shoutime=@shoutime");
			strSql.Append(" where sid=@sid ");
			SqlParameter[] parameters = {
					new SqlParameter("@sid", SqlDbType.Int,4),
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@username", SqlDbType.VarChar,50),
					new SqlParameter("@shoutime", SqlDbType.DateTime)};
			parameters[0].Value = model.sid;
			parameters[1].Value = model.pid;
			parameters[2].Value = model.username;
			parameters[3].Value = model.shoutime;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public int Delete(int sid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from shoucang ");
			strSql.Append(" where sid=@sid ");
			SqlParameter[] parameters = {
					new SqlParameter("@sid", SqlDbType.Int,4)};
			parameters[0].Value = sid;

		return	DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.shoucang GetModel(int sid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 sid,pid,username,shoutime from shoucang ");
			strSql.Append(" where sid=@sid ");
			SqlParameter[] parameters = {
					new SqlParameter("@sid", SqlDbType.Int,4)};
			parameters[0].Value = sid;

			CAI.SHOP.Model.shoucang model=new CAI.SHOP.Model.shoucang();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["sid"].ToString()!="")
				{
					model.sid=int.Parse(ds.Tables[0].Rows[0]["sid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["pid"].ToString()!="")
				{
					model.pid=int.Parse(ds.Tables[0].Rows[0]["pid"].ToString());
				}
				model.username=ds.Tables[0].Rows[0]["username"].ToString();
				if(ds.Tables[0].Rows[0]["shoutime"].ToString()!="")
				{
					model.shoutime=DateTime.Parse(ds.Tables[0].Rows[0]["shoutime"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select sid,pid,username,shoutime ");
			strSql.Append(" FROM shoucang ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" sid,pid,username,shoutime ");
			strSql.Append(" FROM shoucang ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "shoucang";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

