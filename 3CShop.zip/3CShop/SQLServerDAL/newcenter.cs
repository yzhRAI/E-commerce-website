using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����newcenter��
	/// </summary>
	public class newcenter:Inewcenter
	{
		public newcenter()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("nid", "newcenter"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int nid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from newcenter");
			strSql.Append(" where nid=@nid ");
			SqlParameter[] parameters = {
					new SqlParameter("@nid", SqlDbType.Int,4)};
			parameters[0].Value = nid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.newcenter model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into newcenter(");
			strSql.Append("newtitle,newcontact,newshijian,hittime)");
			strSql.Append(" values (");
			strSql.Append("@newtitle,@newcontact,@newshijian,@hittime)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@newtitle", SqlDbType.VarChar,50),
					new SqlParameter("@newcontact", SqlDbType.Text),
					new SqlParameter("@newshijian", SqlDbType.DateTime),
					new SqlParameter("@hittime", SqlDbType.Int,4)};
			parameters[0].Value = model.newtitle;
			parameters[1].Value = model.newcontact;
			parameters[2].Value = model.newshijian;
			parameters[3].Value = model.hittime;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.newcenter model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update newcenter set ");
			strSql.Append("newtitle=@newtitle,");
			strSql.Append("newcontact=@newcontact,");
			strSql.Append("newshijian=@newshijian,");
			strSql.Append("hittime=@hittime");
			strSql.Append(" where nid=@nid ");
			SqlParameter[] parameters = {
					new SqlParameter("@nid", SqlDbType.Int,4),
					new SqlParameter("@newtitle", SqlDbType.VarChar,50),
					new SqlParameter("@newcontact", SqlDbType.Text),
					new SqlParameter("@newshijian", SqlDbType.DateTime),
					new SqlParameter("@hittime", SqlDbType.Int,4)};
			parameters[0].Value = model.nid;
			parameters[1].Value = model.newtitle;
			parameters[2].Value = model.newcontact;
			parameters[3].Value = model.newshijian;
			parameters[4].Value = model.hittime;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int nid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from newcenter ");
			strSql.Append(" where nid=@nid ");
			SqlParameter[] parameters = {
					new SqlParameter("@nid", SqlDbType.Int,4)};
			parameters[0].Value = nid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.newcenter GetModel(int nid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 nid,newtitle,newcontact,newshijian,hittime from newcenter ");
			strSql.Append(" where nid=@nid ");
			SqlParameter[] parameters = {
					new SqlParameter("@nid", SqlDbType.Int,4)};
			parameters[0].Value = nid;

			CAI.SHOP.Model.newcenter model=new CAI.SHOP.Model.newcenter();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["nid"].ToString()!="")
				{
					model.nid=int.Parse(ds.Tables[0].Rows[0]["nid"].ToString());
				}
				model.newtitle=ds.Tables[0].Rows[0]["newtitle"].ToString();
				model.newcontact=ds.Tables[0].Rows[0]["newcontact"].ToString();
				if(ds.Tables[0].Rows[0]["newshijian"].ToString()!="")
				{
					model.newshijian=DateTime.Parse(ds.Tables[0].Rows[0]["newshijian"].ToString());
				}
				if(ds.Tables[0].Rows[0]["hittime"].ToString()!="")
				{
					model.hittime=int.Parse(ds.Tables[0].Rows[0]["hittime"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select nid,newtitle,newcontact,newshijian,hittime ");
			strSql.Append(" FROM newcenter ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" nid,newtitle,newcontact,newshijian,hittime ");
			strSql.Append(" FROM newcenter ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "newcenter";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

