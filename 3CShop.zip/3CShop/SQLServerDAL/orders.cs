using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����orders��
	/// </summary>
	public class orders:Iorders
	{
		public orders()
		{}
		#region  ��Ա����

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int oid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from orders");
			strSql.Append(" where oid=@oid ");
			SqlParameter[] parameters = {
					new SqlParameter("@oid", SqlDbType.Int,4)};
			parameters[0].Value = oid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}

        public void Getoid()
        {

            StringBuilder strSql = new StringBuilder();
            strSql.Append("SELECT @@IDENTITY AS 'Identity'");
             DbHelperSQL.Query(strSql.ToString());
        }

		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.orders model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into orders(");
			strSql.Append("orderid,username,userid,shouhuoname,address,postcode,telephone,songhuofs,fukuanfs,dingdanshijian,dingdantotal,beizhu,djifen)");
			strSql.Append(" values (");
			strSql.Append("@orderid,@username,@userid,@shouhuoname,@address,@postcode,@telephone,@songhuofs,@fukuanfs,@dingdanshijian,@dingdantotal,@beizhu,@djifen)");
            strSql.Append(";SELECT @@IDENTITY AS 'Identity'");
			SqlParameter[] parameters = {
					new SqlParameter("@orderid", SqlDbType.VarChar,50),
					new SqlParameter("@username", SqlDbType.VarChar,50),
					new SqlParameter("@userid", SqlDbType.Int,4),
					new SqlParameter("@shouhuoname", SqlDbType.VarChar,50),
					new SqlParameter("@address", SqlDbType.NVarChar,200),
					new SqlParameter("@postcode", SqlDbType.NVarChar,50),
					new SqlParameter("@telephone", SqlDbType.NVarChar,50),
					new SqlParameter("@songhuofs", SqlDbType.NVarChar,50),
					new SqlParameter("@fukuanfs", SqlDbType.NVarChar,50),
		
					new SqlParameter("@dingdanshijian", SqlDbType.DateTime),
					new SqlParameter("@dingdantotal", SqlDbType.Decimal,9),
					new SqlParameter("@beizhu", SqlDbType.VarChar,50),
					new SqlParameter("@djifen", SqlDbType.Int,4)};
			parameters[0].Value = model.orderid;
			parameters[1].Value = model.username;
			parameters[2].Value = model.userid;
			parameters[3].Value = model.shouhuoname;
			parameters[4].Value = model.address;
			parameters[5].Value = model.postcode;
			parameters[6].Value = model.telephone;
			parameters[7].Value = model.songhuofs;
			parameters[8].Value = model.fukuanfs;
			
			parameters[9].Value = model.dingdanshijian;
			parameters[10].Value = model.dingdantotal;
			parameters[11].Value = model.beizhu;
			parameters[12].Value = model.djifen;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public int Update(CAI.SHOP.Model.orders model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update orders set ");
			strSql.Append("orderid=@orderid,");
			strSql.Append("username=@username,");
			strSql.Append("userid=@userid,");
			strSql.Append("shouhuoname=@shouhuoname,");
			strSql.Append("address=@address,");
			strSql.Append("postcode=@postcode,");
			strSql.Append("telephone=@telephone,");
			strSql.Append("songhuofs=@songhuofs,");
			strSql.Append("fukuanfs=@fukuanfs,");
			strSql.Append("dingdanfeel=@dingdanfeel,");
			strSql.Append("dingdanshijian=@dingdanshijian,");
			strSql.Append("dingdantotal=@dingdantotal,");
			strSql.Append("beizhu=@beizhu,");
			strSql.Append("djifen=@djifen");
			strSql.Append(" where oid=@oid ");
			SqlParameter[] parameters = {
					new SqlParameter("@oid", SqlDbType.Int,4),
					new SqlParameter("@orderid", SqlDbType.VarChar,50),
					new SqlParameter("@username", SqlDbType.VarChar,50),
					new SqlParameter("@userid", SqlDbType.Int,4),
					new SqlParameter("@shouhuoname", SqlDbType.VarChar,50),
					new SqlParameter("@address", SqlDbType.NVarChar,200),
					new SqlParameter("@postcode", SqlDbType.NVarChar,50),
					new SqlParameter("@telephone", SqlDbType.NVarChar,50),
					new SqlParameter("@songhuofs", SqlDbType.NVarChar,50),
					new SqlParameter("@fukuanfs", SqlDbType.NVarChar,50),
					new SqlParameter("@dingdanfeel", SqlDbType.Int,4),
					new SqlParameter("@dingdanshijian", SqlDbType.DateTime),
					new SqlParameter("@dingdantotal", SqlDbType.Decimal,9),
					new SqlParameter("@beizhu", SqlDbType.VarChar,50),
					new SqlParameter("@djifen", SqlDbType.Int,4)};
			parameters[0].Value = model.oid;
			parameters[1].Value = model.orderid;
			parameters[2].Value = model.username;
			parameters[3].Value = model.userid;
			parameters[4].Value = model.shouhuoname;
			parameters[5].Value = model.address;
			parameters[6].Value = model.postcode;
			parameters[7].Value = model.telephone;
			parameters[8].Value = model.songhuofs;
			parameters[9].Value = model.fukuanfs;
			parameters[10].Value = model.dingdanfeel;
			parameters[11].Value = model.dingdanshijian;
			parameters[12].Value = model.dingdantotal;
			parameters[13].Value = model.beizhu;
			parameters[14].Value = model.djifen;

		return	DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public int Delete(int oid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from orders ");
			strSql.Append(" where oid=@oid ");
			SqlParameter[] parameters = {
					new SqlParameter("@oid", SqlDbType.Int,4)};
			parameters[0].Value = oid;

		return	DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.orders GetModel(int oid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 oid,orderid,username,userid,shouhuoname,address,postcode,telephone,songhuofs,fukuanfs,dingdanfeel,dingdanshijian,dingdantotal,beizhu,djifen from orders ");
			strSql.Append(" where oid=@oid ");
			SqlParameter[] parameters = {
					new SqlParameter("@oid", SqlDbType.Int,4)};
			parameters[0].Value = oid;

			CAI.SHOP.Model.orders model=new CAI.SHOP.Model.orders();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["oid"].ToString()!="")
				{
					model.oid=int.Parse(ds.Tables[0].Rows[0]["oid"].ToString());
				}
				model.orderid=ds.Tables[0].Rows[0]["orderid"].ToString();
				model.username=ds.Tables[0].Rows[0]["username"].ToString();
				if(ds.Tables[0].Rows[0]["userid"].ToString()!="")
				{
					model.userid=int.Parse(ds.Tables[0].Rows[0]["userid"].ToString());
				}
				model.shouhuoname=ds.Tables[0].Rows[0]["shouhuoname"].ToString();
				model.address=ds.Tables[0].Rows[0]["address"].ToString();
				model.postcode=ds.Tables[0].Rows[0]["postcode"].ToString();
				model.telephone=ds.Tables[0].Rows[0]["telephone"].ToString();
				model.songhuofs=ds.Tables[0].Rows[0]["songhuofs"].ToString();
				model.fukuanfs=ds.Tables[0].Rows[0]["fukuanfs"].ToString();
				if(ds.Tables[0].Rows[0]["dingdanfeel"].ToString()!="")
				{
					model.dingdanfeel=int.Parse(ds.Tables[0].Rows[0]["dingdanfeel"].ToString());
				}
				if(ds.Tables[0].Rows[0]["dingdanshijian"].ToString()!="")
				{
					model.dingdanshijian=DateTime.Parse(ds.Tables[0].Rows[0]["dingdanshijian"].ToString());
				}
				if(ds.Tables[0].Rows[0]["dingdantotal"].ToString()!="")
				{
					model.dingdantotal=decimal.Parse(ds.Tables[0].Rows[0]["dingdantotal"].ToString());
				}
				model.beizhu=ds.Tables[0].Rows[0]["beizhu"].ToString();
				if(ds.Tables[0].Rows[0]["djifen"].ToString()!="")
				{
					model.djifen=int.Parse(ds.Tables[0].Rows[0]["djifen"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select oid,orderid,username,userid,shouhuoname,address,postcode,telephone,songhuofs,fukuanfs,dingdanfeel,dingdanshijian,dingdantotal,beizhu,djifen ");
			strSql.Append(" FROM orders ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" oid,orderid,username,userid,shouhuoname,address,postcode,telephone,songhuofs,fukuanfs,dingdanfeel,dingdanshijian,dingdantotal,beizhu,djifen ");
			strSql.Append(" FROM orders ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "orders";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

