using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����orderdetail��
	/// </summary>
	public class orderdetail:Iorderdetail
	{
		public orderdetail()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("detailid", "orderdetail"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int detailid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from orderdetail");
			strSql.Append(" where detailid=@detailid ");
			SqlParameter[] parameters = {
					new SqlParameter("@detailid", SqlDbType.Int,4)};
			parameters[0].Value = detailid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.orderdetail model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into orderdetail(");
			strSql.Append("pid,shuliang,orderid,producttotail)");
			strSql.Append(" values (");
			strSql.Append("@pid,@shuliang,@orderid,@producttotail)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@shuliang", SqlDbType.Int,4),
					new SqlParameter("@orderid", SqlDbType.VarChar,50),
					new SqlParameter("@producttotail", SqlDbType.Decimal,9)};
			parameters[0].Value = model.pid;
			parameters[1].Value = model.shuliang;
			parameters[2].Value = model.orderid;
			parameters[3].Value = model.producttotail;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.orderdetail model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update orderdetail set ");
			strSql.Append("pid=@pid,");
			strSql.Append("shuliang=@shuliang,");
			strSql.Append("orderid=@orderid,");
			strSql.Append("producttotail=@producttotail");
			strSql.Append(" where detailid=@detailid ");
			SqlParameter[] parameters = {
					new SqlParameter("@detailid", SqlDbType.Int,4),
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@shuliang", SqlDbType.Int,4),
					new SqlParameter("@orderid", SqlDbType.VarChar,50),
					new SqlParameter("@producttotail", SqlDbType.Decimal,9)};
			parameters[0].Value = model.detailid;
			parameters[1].Value = model.pid;
			parameters[2].Value = model.shuliang;
			parameters[3].Value = model.orderid;
			parameters[4].Value = model.producttotail;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int detailid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from orderdetail ");
			strSql.Append(" where detailid=@detailid ");
			SqlParameter[] parameters = {
					new SqlParameter("@detailid", SqlDbType.Int,4)};
			parameters[0].Value = detailid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.orderdetail GetModel(int detailid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 detailid,pid,shuliang,orderid,producttotail from orderdetail ");
			strSql.Append(" where detailid=@detailid ");
			SqlParameter[] parameters = {
					new SqlParameter("@detailid", SqlDbType.Int,4)};
			parameters[0].Value = detailid;

			CAI.SHOP.Model.orderdetail model=new CAI.SHOP.Model.orderdetail();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["detailid"].ToString()!="")
				{
					model.detailid=int.Parse(ds.Tables[0].Rows[0]["detailid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["pid"].ToString()!="")
				{
					model.pid=int.Parse(ds.Tables[0].Rows[0]["pid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["shuliang"].ToString()!="")
				{
					model.shuliang=int.Parse(ds.Tables[0].Rows[0]["shuliang"].ToString());
				}
				model.orderid=ds.Tables[0].Rows[0]["orderid"].ToString();
				if(ds.Tables[0].Rows[0]["producttotail"].ToString()!="")
				{
					model.producttotail=decimal.Parse(ds.Tables[0].Rows[0]["producttotail"].ToString());
				}
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select detailid,pid,shuliang,orderid,producttotail ");
			strSql.Append(" FROM orderdetail ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" detailid,pid,shuliang,orderid,producttotail ");
			strSql.Append(" FROM orderdetail ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "orderdetail";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

