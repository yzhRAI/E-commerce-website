using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����leibiex��
	/// </summary>
	public class leibiex:Ileibiex
	{
		public leibiex()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("Classxid", "leibiex"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int Classxid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from leibiex");
			strSql.Append(" where Classxid=@Classxid ");
			SqlParameter[] parameters = {
					new SqlParameter("@Classxid", SqlDbType.Int,4)};
			parameters[0].Value = Classxid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.leibiex model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into leibiex(");
			strSql.Append("Classid,Classxname)");
			strSql.Append(" values (");
			strSql.Append("@Classid,@Classxname)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@Classid", SqlDbType.Int,4),
					new SqlParameter("@Classxname", SqlDbType.NVarChar,50)};
			parameters[0].Value = model.Classid;
			parameters[1].Value = model.Classxname;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.leibiex model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update leibiex set ");
			strSql.Append("Classid=@Classid,");
			strSql.Append("Classxname=@Classxname");
			strSql.Append(" where Classxid=@Classxid ");
			SqlParameter[] parameters = {
					new SqlParameter("@Classxid", SqlDbType.Int,4),
					new SqlParameter("@Classid", SqlDbType.Int,4),
					new SqlParameter("@Classxname", SqlDbType.NVarChar,50)};
			parameters[0].Value = model.Classxid;
			parameters[1].Value = model.Classid;
			parameters[2].Value = model.Classxname;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int Classxid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from leibiex ");
			strSql.Append(" where Classxid=@Classxid ");
			SqlParameter[] parameters = {
					new SqlParameter("@Classxid", SqlDbType.Int,4)};
			parameters[0].Value = Classxid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.leibiex GetModel(int Classxid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 Classxid,Classid,Classxname from leibiex ");
			strSql.Append(" where Classxid=@Classxid ");
			SqlParameter[] parameters = {
					new SqlParameter("@Classxid", SqlDbType.Int,4)};
			parameters[0].Value = Classxid;

			CAI.SHOP.Model.leibiex model=new CAI.SHOP.Model.leibiex();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["Classxid"].ToString()!="")
				{
					model.Classxid=int.Parse(ds.Tables[0].Rows[0]["Classxid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["Classid"].ToString()!="")
				{
					model.Classid=int.Parse(ds.Tables[0].Rows[0]["Classid"].ToString());
				}
				model.Classxname=ds.Tables[0].Rows[0]["Classxname"].ToString();
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
            strSql.Append("select Classxid,Classid,Classxname,Classname ");
            strSql.Append(" FROM V_leibie ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
            strSql.Append(" Classxid,Classid,Classxname,,Classname ");
            strSql.Append(" FROM V_leibie ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "leibiex";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

