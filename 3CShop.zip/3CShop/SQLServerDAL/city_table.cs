using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����city_table��
	/// </summary>
	public class city_table:Icity_table
	{
		public city_table()
		{}
		#region  ��Ա����

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int id)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from city_table");
			strSql.Append(" where id=@id ");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
			parameters[0].Value = id;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.city_table model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into city_table(");
			strSql.Append("oneid,twoid,three,name)");
			strSql.Append(" values (");
			strSql.Append("@oneid,@twoid,@three,@name)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@oneid", SqlDbType.Int,4),
					new SqlParameter("@twoid", SqlDbType.Int,4),
					new SqlParameter("@three", SqlDbType.Int,4),
					new SqlParameter("@name", SqlDbType.VarChar,50)};
			parameters[0].Value = model.oneid;
			parameters[1].Value = model.twoid;
			parameters[2].Value = model.three;
			parameters[3].Value = model.name;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.city_table model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update city_table set ");
			strSql.Append("oneid=@oneid,");
			strSql.Append("twoid=@twoid,");
			strSql.Append("three=@three,");
			strSql.Append("name=@name");
			strSql.Append(" where id=@id ");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4),
					new SqlParameter("@oneid", SqlDbType.Int,4),
					new SqlParameter("@twoid", SqlDbType.Int,4),
					new SqlParameter("@three", SqlDbType.Int,4),
					new SqlParameter("@name", SqlDbType.VarChar,50)};
			parameters[0].Value = model.id;
			parameters[1].Value = model.oneid;
			parameters[2].Value = model.twoid;
			parameters[3].Value = model.three;
			parameters[4].Value = model.name;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from city_table ");
			strSql.Append(" where id=@id ");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
			parameters[0].Value = id;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.city_table GetModel(int id)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 id,oneid,twoid,three,name from city_table ");
			strSql.Append(" where id=@id ");
			SqlParameter[] parameters = {
					new SqlParameter("@id", SqlDbType.Int,4)};
			parameters[0].Value = id;

			CAI.SHOP.Model.city_table model=new CAI.SHOP.Model.city_table();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["id"].ToString()!="")
				{
					model.id=int.Parse(ds.Tables[0].Rows[0]["id"].ToString());
				}
				if(ds.Tables[0].Rows[0]["oneid"].ToString()!="")
				{
					model.oneid=int.Parse(ds.Tables[0].Rows[0]["oneid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["twoid"].ToString()!="")
				{
					model.twoid=int.Parse(ds.Tables[0].Rows[0]["twoid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["three"].ToString()!="")
				{
					model.three=int.Parse(ds.Tables[0].Rows[0]["three"].ToString());
				}
				model.name=ds.Tables[0].Rows[0]["name"].ToString();
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select id,oneid,twoid,three,name ");
			strSql.Append(" FROM city_table ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" id,oneid,twoid,three,name ");
			strSql.Append(" FROM city_table ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "city_table";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

