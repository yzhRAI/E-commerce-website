using System;
using System.Data;
using System.Text;
using System.Data.SqlClient;
using CAI.SHOP.IDAL;
using Maticsoft.DBUtility;//������������
namespace CAI.SHOP.SQLServerDAL
{
	/// <summary>
	/// ���ݷ�����productliuyan��
	/// </summary>
	public class productliuyan:Iproductliuyan
	{
		public productliuyan()
		{}
		#region  ��Ա����

		/// <summary>
		/// �õ����ID
		/// </summary>
		public int GetMaxId()
		{
		return DbHelperSQL.GetMaxID("lid", "productliuyan"); 
		}

		/// <summary>
		/// �Ƿ���ڸü�¼
		/// </summary>
		public bool Exists(int lid)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select count(1) from productliuyan");
			strSql.Append(" where lid=@lid ");
			SqlParameter[] parameters = {
					new SqlParameter("@lid", SqlDbType.Int,4)};
			parameters[0].Value = lid;

			return DbHelperSQL.Exists(strSql.ToString(),parameters);
		}


		/// <summary>
		/// ����һ������
		/// </summary>
		public int Add(CAI.SHOP.Model.productliuyan model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("insert into productliuyan(");
			strSql.Append("pid,liuname,liutime,liuzhu,liuhui,huifutime)");
			strSql.Append(" values (");
			strSql.Append("@pid,@liuname,@liutime,@liuzhu,@liuhui,@huifutime)");
			strSql.Append(";select @@IDENTITY");
			SqlParameter[] parameters = {
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@liuname", SqlDbType.VarChar,50),
					new SqlParameter("@liutime", SqlDbType.DateTime),
					new SqlParameter("@liuzhu", SqlDbType.NVarChar,1000),
					new SqlParameter("@liuhui", SqlDbType.NVarChar,1000),
					new SqlParameter("@huifutime", SqlDbType.VarChar,50)};
			parameters[0].Value = model.pid;
			parameters[1].Value = model.liuname;
			parameters[2].Value = model.liutime;
			parameters[3].Value = model.liuzhu;
			parameters[4].Value = model.liuhui;
			parameters[5].Value = model.huifutime;

			object obj = DbHelperSQL.GetSingle(strSql.ToString(),parameters);
			if (obj == null)
			{
				return 1;
			}
			else
			{
				return Convert.ToInt32(obj);
			}
		}
		/// <summary>
		/// ����һ������
		/// </summary>
		public void Update(CAI.SHOP.Model.productliuyan model)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("update productliuyan set ");
			strSql.Append("pid=@pid,");
			strSql.Append("liuname=@liuname,");
			strSql.Append("liutime=@liutime,");
			strSql.Append("liuzhu=@liuzhu,");
			strSql.Append("liuhui=@liuhui,");
			strSql.Append("huifutime=@huifutime");
			strSql.Append(" where lid=@lid ");
			SqlParameter[] parameters = {
					new SqlParameter("@lid", SqlDbType.Int,4),
					new SqlParameter("@pid", SqlDbType.Int,4),
					new SqlParameter("@liuname", SqlDbType.VarChar,50),
					new SqlParameter("@liutime", SqlDbType.DateTime),
					new SqlParameter("@liuzhu", SqlDbType.NVarChar,1000),
					new SqlParameter("@liuhui", SqlDbType.NVarChar,1000),
					new SqlParameter("@huifutime", SqlDbType.VarChar,50)};
			parameters[0].Value = model.lid;
			parameters[1].Value = model.pid;
			parameters[2].Value = model.liuname;
			parameters[3].Value = model.liutime;
			parameters[4].Value = model.liuzhu;
			parameters[5].Value = model.liuhui;
			parameters[6].Value = model.huifutime;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}

		/// <summary>
		/// ɾ��һ������
		/// </summary>
		public void Delete(int lid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("delete from productliuyan ");
			strSql.Append(" where lid=@lid ");
			SqlParameter[] parameters = {
					new SqlParameter("@lid", SqlDbType.Int,4)};
			parameters[0].Value = lid;

			DbHelperSQL.ExecuteSql(strSql.ToString(),parameters);
		}


		/// <summary>
		/// �õ�һ������ʵ��
		/// </summary>
		public CAI.SHOP.Model.productliuyan GetModel(int lid)
		{
			
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select  top 1 lid,pid,liuname,liutime,liuzhu,liuhui,huifutime from productliuyan ");
			strSql.Append(" where lid=@lid ");
			SqlParameter[] parameters = {
					new SqlParameter("@lid", SqlDbType.Int,4)};
			parameters[0].Value = lid;

			CAI.SHOP.Model.productliuyan model=new CAI.SHOP.Model.productliuyan();
			DataSet ds=DbHelperSQL.Query(strSql.ToString(),parameters);
			if(ds.Tables[0].Rows.Count>0)
			{
				if(ds.Tables[0].Rows[0]["lid"].ToString()!="")
				{
					model.lid=int.Parse(ds.Tables[0].Rows[0]["lid"].ToString());
				}
				if(ds.Tables[0].Rows[0]["pid"].ToString()!="")
				{
					model.pid=int.Parse(ds.Tables[0].Rows[0]["pid"].ToString());
				}
				model.liuname=ds.Tables[0].Rows[0]["liuname"].ToString();
				if(ds.Tables[0].Rows[0]["liutime"].ToString()!="")
				{
					model.liutime=DateTime.Parse(ds.Tables[0].Rows[0]["liutime"].ToString());
				}
				model.liuzhu=ds.Tables[0].Rows[0]["liuzhu"].ToString();
				model.liuhui=ds.Tables[0].Rows[0]["liuhui"].ToString();
				model.huifutime=ds.Tables[0].Rows[0]["huifutime"].ToString();
				return model;
			}
			else
			{
				return null;
			}
		}

		/// <summary>
		/// ��������б�
		/// </summary>
		public DataSet GetList(string strWhere)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select lid,pid,liuname,liutime,liuzhu,liuhui,huifutime ");
			strSql.Append(" FROM productliuyan ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			return DbHelperSQL.Query(strSql.ToString());
		}

		/// <summary>
		/// ���ǰ��������
		/// </summary>
		public DataSet GetList(int Top,string strWhere,string filedOrder)
		{
			StringBuilder strSql=new StringBuilder();
			strSql.Append("select ");
			if(Top>0)
			{
				strSql.Append(" top "+Top.ToString());
			}
			strSql.Append(" lid,pid,liuname,liutime,liuzhu,liuhui,huifutime ");
			strSql.Append(" FROM productliuyan ");
			if(strWhere.Trim()!="")
			{
				strSql.Append(" where "+strWhere);
			}
			strSql.Append(" order by " + filedOrder);
			return DbHelperSQL.Query(strSql.ToString());
		}

		/*
		/// <summary>
		/// ��ҳ��ȡ�����б�
		/// </summary>
		public DataSet GetList(int PageSize,int PageIndex,string strWhere)
		{
			SqlParameter[] parameters = {
					new SqlParameter("@tblName", SqlDbType.VarChar, 255),
					new SqlParameter("@fldName", SqlDbType.VarChar, 255),
					new SqlParameter("@PageSize", SqlDbType.Int),
					new SqlParameter("@PageIndex", SqlDbType.Int),
					new SqlParameter("@IsReCount", SqlDbType.Bit),
					new SqlParameter("@OrderType", SqlDbType.Bit),
					new SqlParameter("@strWhere", SqlDbType.VarChar,1000),
					};
			parameters[0].Value = "productliuyan";
			parameters[1].Value = "ID";
			parameters[2].Value = PageSize;
			parameters[3].Value = PageIndex;
			parameters[4].Value = 0;
			parameters[5].Value = 0;
			parameters[6].Value = strWhere;	
			return DbHelperSQL.RunProcedure("UP_GetRecordByPage",parameters,"ds");
		}*/

		#endregion  ��Ա����
	}
}

