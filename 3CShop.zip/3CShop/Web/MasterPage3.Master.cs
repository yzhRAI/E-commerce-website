﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class MasterPage3 : System.Web.UI.MasterPage
    {
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.BLL.shoucang shoucangbll = new CAI.SHOP.BLL.shoucang();
        CAI.SHOP.Model.shoucang shoucangmodel = new CAI.SHOP.Model.shoucang();
        CAI.SHOP.BLL.newcenter newcenterbll = new CAI.SHOP.BLL.newcenter();
        CAI.SHOP.BLL.leibie leibiebll = new CAI.SHOP.BLL.leibie();
        CAI.SHOP.BLL.leibiex leibiexbll = new CAI.SHOP.BLL.leibiex();
        protected void Page_Load(object sender, EventArgs e)
        {
            bide();
            bidg();
        }

        public void bide()
        {
            
        }

        public void bidg()
        {
           

        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

        }
        protected void DataList8_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        Page.RegisterClientScriptBlock("e", "<script>alert('收藏成功!')</script>");
                    }
                    else
                    {
                        Page.RegisterClientScriptBlock("e", "<script>alert('收藏失败!')</script>");
                       
                    }
                }
            }
        }
        protected void DataList8_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex
        }
        protected void DataList9_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        Page.RegisterClientScriptBlock("e", "<script>alert('收藏成功!')</script>");
                    }
                    else
                    {
                        Page.RegisterClientScriptBlock("e", "<script>alert('收藏失败!')</script>");
                    }

                }
            }
        }
        protected void DataList9_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex
        }
    }
}
