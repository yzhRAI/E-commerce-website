﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

namespace CAI.SHOP.Web
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        string connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            fenye();
            //  string mysql = "select * from product where classid='" + Request.QueryString["id"] + "'and productname like '%'+'" +Request.QueryString["productname"]+ "'+'%'";
            //DataList1.DataSource = Class1.gd(mysql);
            //DataList1.DataBind();
            //  GridView2.DataSource = Class1.gd(mysql);
            // GridView2.DataBind();
        }
        public void fenye()
        {
            string mysqlba = "select * from product where  productname like '%'+'" + Request.QueryString["productname"] + "'+'%'";

            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();
            SqlCommand cmd = new SqlCommand(mysqlba, conn);
            DataSet ds = new DataSet();
            SqlDataAdapter sdr = new SqlDataAdapter(cmd);
            sdr.Fill(ds);
            DataView dv = ds.Tables[0].DefaultView;
            PagedDataSource pds = new PagedDataSource();

            AspNetPager1.RecordCount = dv.Count;
            pds.DataSource = dv;
            pds.AllowPaging = true;
            pds.CurrentPageIndex = AspNetPager1.CurrentPageIndex - 1;
            pds.PageSize = AspNetPager1.PageSize;
            this.DataList1.DataSource = pds;
            this.DataList1.DataBind();


        }
        protected void AspNetPager1_PageChanged(object sender, EventArgs e)
        {
            fenye();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {



        }
        protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
        {

            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='images/buy.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 

            //  this.LinkButton1.Text =
        }

        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {

            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                // Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {
                    Label pid = (Label)e.Item.FindControl("pid");
                    int piid = Convert.ToInt32(pid.Text);
                    string mysql = "insert into shoucang(pid,username,shoutime)values('" + piid + "','" + Session["username"].ToString() + "','" + System.DateTime.Now + "')";
                    SqlConnection conn = new SqlConnection(connstr);
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(mysql, conn);


                    int n = cmd.ExecuteNonQuery();
                    if (n > 0)
                    {
                        Page.RegisterClientScriptBlock("e", "<script>alert('收藏成功')</script>");
                    }
                }
            }

        }
    }
}