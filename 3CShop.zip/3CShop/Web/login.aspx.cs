﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class login : System.Web.UI.Page
    {

        CAI.SHOP.BLL.d_users userbll = new CAI.SHOP.BLL.d_users();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void imgBtnLogin_Click1(object sender, ImageClickEventArgs e)
        {
            if (0 == txtName.Text.Length)
            {
                txtName.Focus();
                Page.RegisterClientScriptBlock("e", "<script>alert('请输入用户名！')</script>");
                return;
            }

            if (0 == txtPwd.Text.Length)
            {
                txtPwd.Focus();
                Page.RegisterClientScriptBlock("e", "<script>alert('请输入密码！')</script>");
                return;
            }

            string username=txtName.Text;
            string password=txtPwd.Text;

          bool success = userbll.Exists(username, password);

            if (success)
            {
                Session["username"] = txtName.Text.ToString();
                Response.Redirect("default.aspx");

            }
            else
            {

               
                txtPwd.Focus();
                LTP.Common.MessageBox.Show(this, "很遗憾，用户名或密码不正确");

                Session.Clear();
                // Response.Write("<script>alert('恭喜您,登陆成功啦!');location.href='default.aspx'</script>");
                // Label1.Text = Session["user_name"].ToString();
            }
        }
    }
}
