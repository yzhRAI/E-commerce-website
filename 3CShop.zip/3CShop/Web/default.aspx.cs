﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class _default : System.Web.UI.Page
    {
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.BLL.shoucang shoucangbll = new CAI.SHOP.BLL.shoucang();
        CAI.SHOP.Model.shoucang shoucangmodel = new CAI.SHOP.Model.shoucang();
        CAI.SHOP.BLL.newcenter newcenterbll = new CAI.SHOP.BLL.newcenter();
        CAI.SHOP.BLL.leibie leibiebll = new CAI.SHOP.BLL.leibie();
        CAI.SHOP.BLL.leibiex leibiexbll = new CAI.SHOP.BLL.leibiex();
        protected void Page_Load(object sender, EventArgs e)
        {

            wwwq();
            bid();
            bida();
        }

        public void bid()
        {
          
        }

        public void bida()
        {

            

            DataSet dsa = productbll.GetList(10, "newproduct=1", "pid desc");
            DataList6.DataSource = dsa;
            DataList6.DataBind();



            DataSet dsb = productbll.GetList(10, "newproduct=3", "pid desc");
            DataList4.DataSource = dsb;
            DataList4.DataBind();


            DataSet dsc = productbll.GetList(10, "", "adddate desc");
            DataList1.DataSource = dsc;
            DataList1.DataBind();



            DataSet dser = productbll.GetList(5, "", "sl desc");
            GridView4.DataSource = dser;
            GridView4.DataBind();



            DataSet dst = productbll.GetList(2, "", "newid()");
            DataList5.DataSource = dst;
            DataList5.DataBind();



            DataSet dsg = leibiebll.GetAllList();
           DataList2.DataSource = dsg;
           DataList2.DataBind();
            
        }

        public void wwwq()
        {

            DataSet ds = new DataSet();
            ds = Getfromxlm();

            string keyy = ds.Tables[0].Rows[0][0].ToString();
            string desss = ds.Tables[0].Rows[0][1].ToString();
            string biaoti = ds.Tables[0].Rows[0][2].ToString();

            Page.Title = biaoti.ToString();

            HtmlMeta desc = new HtmlMeta();
            desc.Name = "Description";
            desc.Content = desss.ToString();
            Page.Header.Controls.Add(desc);

            HtmlMeta keywords = new HtmlMeta();
            keywords.Name = "keywords";
            keywords.Content = keyy.ToString(); ;
            Page.Header.Controls.Add(keywords);



        }

        public DataSet Getfromxlm()
        {
            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(MapPath("~/updatein.xml"));
            }
            catch
            {
                Response.Write("<Script>alert('信息文件丢失！')</Script>");
            }
            return ds;
        }



        protected void DataList2_ItemDataBound(object sender, DataListItemEventArgs e)
        {


            /* if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
             {
                 //当鼠标选择某行时变颜色#d8e4f8
                 e.Item.Attributes.Add("onmouseover", "c=this.style.backgroundColor;this.style.backgroundColor='#f7f9ff';");
                 e.Item.Attributes.Add("onmouseout", "this.style.backgroundColor=c;");
             } 
             */
        }

        protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 

            //  this.LinkButton1.Text =
        }
        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid =Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                 int n=shoucangbll.Add(shoucangmodel);

                 if (n > 0)
                 {
                     LTP.Common.MessageBox.Show(this, "收藏成功！");
                 }
                 else
                 {

                     LTP.Common.MessageBox.Show(this, "收藏失败！");
                 }

                }
            }

        }
        protected void DataList4_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 

            //  this.LinkButton1.Text =
        }
        protected void DataList4_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {
                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }

                }
            }
        }
        protected void DataList3_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }
                }






            }
        }
        protected void DataList3_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 

            //  this.LinkButton1.Text =
        }
        protected void DataList6_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 

        }
        protected void DataList6_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }
                }






            }
        }

        protected void DataList8_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }

                }
            }
        }
        protected void DataList8_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
            // string dd = DataList1.DataKeys[e.Item.ItemIndex].ToString(); 
        }
        protected void DataList9_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "buy")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }

                Session["Car"] = hash;
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "shou")
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {

                    string productid = e.CommandArgument.ToString();
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(productid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }

                }
            }
        }
        protected void DataList9_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                lik.Text = @"<img src='77/gm.gif' border='0'>";
                LinkButton like = (LinkButton)e.Item.FindControl("LinkButton2");
                like.Text = @"<img src='77/sc.gif' border='0'>";
            }
        }

        protected void DataList2_ItemDataBound1(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                DataList rptSmallClass = (DataList)e.Item.FindControl("DataList3");
                int bId = Convert.ToInt32(DataBinder.Eval(e.Item.DataItem, "classid"));//得到主键
                DataSet ds = leibiexbll.GetList(" classid=" + bId);
                rptSmallClass.DataSource = ds;
                rptSmallClass.DataBind();
            }
        }

       

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (this.TextBox1.Text == "" && this.TextBox2.Text == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('请输入检索条件！');</script>");
                return;

            }
           
            DataSet dsa = productbll.GetList(10, "newproduct=1 and productname like '%" + TextBox1.Text + "%' and productchu like '%" + TextBox2.Text + "%'", "pid desc");
            DataList6.DataSource = dsa;
            DataList6.DataBind();



            DataSet dsb = productbll.GetList(10, "newproduct=3 and productname like '%" + TextBox1.Text + "%' and productchu like '%" + TextBox2.Text + "%'", "pid desc");
            DataList4.DataSource = dsb;
            DataList4.DataBind();


            DataSet dsc = productbll.GetList(10, " productname like '%" + TextBox1.Text + "%' and productchu like '%" + TextBox2.Text + "%'", "adddate desc");
            DataList1.DataSource = dsc;
            DataList1.DataBind();

            if (dsa.Tables[0].Rows.Count <= 0 || dsb.Tables[0].Rows.Count <= 0 || dsc.Tables[0].Rows.Count <= 0)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('三种列表中存在检索记录为0的商品列表！');</script>");
                return;
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
