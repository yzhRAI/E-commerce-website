﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class shoppingcar : System.Web.UI.Page
    {
        Double TtlPrice;
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!Page.IsPostBack)
            {
                Image13.Visible = false;
                Msg.Visible = false;
                shoplist();
            }

        }

        protected void shoplist()
        {
            Hashtable Hash;
            if (Session["car"] == null)
            {
                Hash = new Hashtable();
            }
            else
            {
                Hash = (Hashtable)Session["car"];
            }
            if (Hash.Count == 0)
            {
                Image13.Visible = true;
                Msg.Visible = true;
                Msg.Text = "您还没有购物呢？赶快购物吧!";
            }

            string[] ArrKey = new string[Hash.Count];
            int[] ArrVal = new int[Hash.Count];
            string Products = "('";
            Hash.Keys.CopyTo(ArrKey, 0);
            Hash.Values.CopyTo(ArrVal, 0);
            int k = 0;
            for (int j = 0; j < ArrKey.Length; j++)
            {
                if (k > 0) Products += "','"; k++;
                Products += ArrKey.GetValue(j).ToString();
            }
            Products += "')";


            DataSet ds = productbll.GetList("pid in" + Products);

            DataTable Table1 = new DataTable();
            Table1 = ds.Tables[0];
           // Table1 = ds.Tables["product"];
            Table1.Columns.Add(new DataColumn("shuliang", System.Type.GetType("System.Int32")));

            DataColumn[] Keys = { Table1.Columns["pid"] };
            Table1.PrimaryKey = Keys;
            foreach (string X in Hash.Keys)
            {
                Table1.Rows.Find(X)["shuliang"] = Hash[X];

            }
            Table1.Columns.Add(new DataColumn("zongjia", System.Type.GetType("System.Double"), "hotprice*shuliang"));


            for (int I = 0; I < Table1.Rows.Count; I++)
            {
                
                
                    TtlPrice += Convert.ToDouble(Table1.Rows[I]["zongjia"]);
              

            }

            Label1.Text = TtlPrice.ToString();
            Session["total"] = Label1.Text.ToString();
            MyGrid.DataSource = Table1.DefaultView;
            MyGrid.DataBind();

        }

        protected void MyGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            Hashtable Hash;
            if (Session["car"] == null)
            {
                Hash = new Hashtable();
            }
            else
            {
                Hash = (Hashtable)Session["car"];
            }

            if (Hash.ContainsKey(e.CommandArgument))
            {
                Hash.Remove(e.CommandArgument);
            }
            Msg.Text = (string)e.CommandArgument;

            Session["car"] = Hash;
            shoplist();
        }
        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            int i;
            Hashtable Hash;
            if (Session["car"] == null)
            {
                Hash = new Hashtable();
            }
            else
            {
                Hash = (Hashtable)Session["car"];

            }

            for (i = 0; i < MyGrid.Rows.Count; i++)
            {
                // CheckBox cb = (CheckBox)GridView1.Rows[i].FindControl("BuyIt");
                Label lb = (Label)MyGrid.Rows[i].FindControl("bianhao");
                TextBox tb = (TextBox)MyGrid.Rows[i].FindControl("shuliang");

                //if (cb.Checked && Int32.Parse(tb.Text) > 0)
                //{
                if (Convert.ToInt32(tb.Text) <= 0)
                {
                    LTP.Common.MessageBox.Show(this, "数量填写错误!");
                  // this.RegisterClientScriptBlock("E", "<script>alert('数量填写错误!')</script>");
                    tb.Focus();
                    return;
                    //ClientScript.RegisterStartupScript(ClientScript.GetType(), "aa", "<script>alert('')</script>");
                }
                else if (!Hash.ContainsKey(lb.Text))
                {
                    Hash.Add(lb.Text, Int32.Parse(tb.Text));
                }
                else
                {
                    Hash[lb.Text] = Convert.ToInt32(tb.Text);
                }
                //}
            }

            Session["car"] = Hash;
            shoplist();
        }
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Session["car"] = null;
            shoplist();
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Redirect("default.aspx");
        }
        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            if (MyGrid.Rows.Count == 0)
            {
                LTP.Common.MessageBox.Show(this, "请先购物!");

               // Page.RegisterClientScriptBlock("e", "<script>alert('请先购物!')</script>");
            }
            else if (Session["username"] == null)
            {

                Response.Write("<script>alert('请先登录!');location.href='login.aspx'</script>");

                // Server.Transfer("userlogin.aspx");
            }
            else
            {

                Response.Redirect("pay1.aspx");
            }
        }
    }
}
