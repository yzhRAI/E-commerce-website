﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class productdetail : System.Web.UI.Page
    {

        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.BLL.shoucang shoucangbll = new CAI.SHOP.BLL.shoucang();
        CAI.SHOP.Model.shoucang shoucangmodel = new CAI.SHOP.Model.shoucang();
        CAI.SHOP.BLL.leibie leibiebll = new CAI.SHOP.BLL.leibie();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {

                bida();
            }
        }

        public void bida()
        {

            DataSet ds = leibiebll.GetAllList();
            DataList2.DataSource = ds;
            DataList2.DataBind();

          



            DataSet dser = productbll.GetList(5, "", "hittimes desc");
            GridView4.DataSource = dser;
            GridView4.DataBind();



            DataSet dst = productbll.GetList(5, "", "newid()");
            DataList3.DataSource = dst;
            DataList3.DataBind();



            DataSet dsg = productbll.GetList("pid='" + Request.QueryString["id"] + "'");
            DataList1.DataSource = dsg;
            DataList1.DataBind();

        }

        protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                TXT.Text = "1";
            }
            // ImageButton jiarugou = (ImageButton)e.Item.FindControl("ImageButton1");
            //ImageButton goumai = (ImageButton)e.Item.FindControl("imagebutton2");

        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("ssnotice.aspx");
            }
            else
            {
                for (int i = 0; i < DataList1.Items.Count; i++)
                {

                    Label pid = (Label)DataList1.Items[i].FindControl("pid");
                    int piid = Convert.ToInt32(pid.Text);

                  
                    string username = Session["username"].ToString();
                    DateTime shijian = System.DateTime.Now;
                    shoucangmodel.pid = Convert.ToInt32(piid);
                    shoucangmodel.username = username;
                    shoucangmodel.shoutime = shijian;

                    int n = shoucangbll.Add(shoucangmodel);

                    if (n > 0)
                    {
                        LTP.Common.MessageBox.Show(this, "收藏成功！");
                    }
                    else
                    {

                        LTP.Common.MessageBox.Show(this, "收藏失败！");
                    }
                }
            }


        }
        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "jiaru")
            {
                int i;
                Hashtable Hash;
                if (Session["car"] == null)
                {
                    Hash = new Hashtable();
                }
                else
                {
                    Hash = (Hashtable)Session["car"];

                }
                for (i = 0; i < DataList1.Items.Count; i++)
                {

                    TextBox tb = (TextBox)DataList1.Items[i].FindControl("quantity");
                    Label lb = (Label)DataList1.Items[i].FindControl("PID");
                    //Label lb = (Label)GridView1.Rows[i].FindControl("PID");
                    // TextBox tb = (TextBox)GridView1.Rows[i].FindControl("quantity");

                    if (Int32.Parse(tb.Text) > 0)
                    {
                        if (!Hash.ContainsKey(lb.Text))
                        {
                            Hash.Add(lb.Text, Int32.Parse(tb.Text));
                        }
                        else
                        {
                            Hash[lb.Text] = (int)Hash[lb.Text] + Convert.ToInt32(tb.Text);
                        }
                    }
                }

                Session["car"] = Hash;
               
            }
            else if (e.CommandName == "like")
            {
                int i;
                Hashtable Hash;
                if (Session["car"] == null)
                {
                    Hash = new Hashtable();
                }
                else
                {
                    Hash = (Hashtable)Session["car"];

                }
                for (i = 0; i < DataList1.Items.Count; i++)
                {


                    TextBox tb = (TextBox)DataList1.Items[i].FindControl("quantity");
                    Label lb = (Label)DataList1.Items[i].FindControl("PID");
                    //Label lb = (Label)GridView1.Rows[i].FindControl("PID");
                    // TextBox tb = (TextBox)GridView1.Rows[i].FindControl("quantity");

                    if (Int32.Parse(tb.Text) > 0)
                    {
                        if (!Hash.ContainsKey(lb.Text))
                        {
                            Hash.Add(lb.Text, Int32.Parse(tb.Text));
                        }
                        else
                        {
                            Hash[lb.Text] = (int)Hash[lb.Text] + Convert.ToInt32(tb.Text);
                        }
                    }
                }

                Session["car"] = Hash;
                Response.Redirect("shoppingcar.aspx");
            }
        }
    }
}
