﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class SPXXList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 在此处放置用户代码以初始化页面
            if (!Page.IsPostBack)
            {
                initDg();
            }
        }
        protected void initDg()
        {
            DataTable dt = new DataTable();
            dt = (new BLL.product()).GetList(" productname like '%" + TextBox1.Text + "%' and productchu like '%"+TextBox2.Text+"%'").Tables[0];
            if (dt.Rows.Count < 1)
                dt.Rows.Add(dt.NewRow());
            this.GridView1.DataSource = dt.DefaultView;
            this.GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //跳转页面 
            Response.Redirect("SPXX.aspx");
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();
            if (e.CommandName == "Mod")
            {
                //传递修改的标志 跳转页面
                Response.Redirect("SPXX.aspx?ID=" + Key);
            }
            else if (e.CommandName == "Del")
            {
                //获取服务器相对路径

                //删除商品信息
                (new BLL.product()).Delete(Convert.ToInt32(Key));
                initDg();

            }
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowIndex != -1)
            {
                if (e.Row.Cells[0].Text == "&nbsp;")
                    e.Row.Cells[this.GridView1.Columns.Count - 1].Visible = false;
            }
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GridView1.PageIndex = e.NewPageIndex;
            initDg();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            initDg();
        }
    }
}
