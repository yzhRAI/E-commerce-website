﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class LoginForm : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TextBox1.Focus();
        }

        [Obsolete]
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

            string mysql;

            DataTable dt= (new BLL.admin()).GetList("admin='" + TextBox1.Text + "'and password='" + TextBox2.Text + "'").Tables[0];
            if (dt.Rows.Count <= 0)
            {

                Page.RegisterClientScriptBlock("e", "<script>alert('很遗憾，用户名和密码都不正确!')</script>");
                Session.Clear();
                TextBox2.Focus();
            }
            else
            {
                Session["admin"] = TextBox1.Text.ToString();
                Response.Redirect("index.aspx");

            }
        }
    }
}
