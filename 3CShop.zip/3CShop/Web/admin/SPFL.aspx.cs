﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class SPFL : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 在此处放置用户代码以初始化页面
            if (!Page.IsPostBack)
            {
                //调用函数
                initDg();
            }
        }

        private void initDg()
        {
            //显示类别列表
            this.GridView1.DataSource = (new BLL.leibie()).GetAllList(); 
            this.GridView1.DataBind();
            this.TextBox1.Text = "";
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //添加类别信息
            Model.leibie yy = new Model.leibie();
            yy.Classname = this.TextBox1.Text;

            (new BLL.leibie()).Add(yy);

            initDg();
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Del")
            {
                //判断记录是否允许删除
                string Key = this.GridView1.DataKeys[Convert.ToInt32(e.CommandArgument)].Value.ToString();

                (new BLL.leibie()).Delete(Convert.ToInt32(Key));
                initDg();
            }
        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            this.GridView1.PageIndex = e.NewPageIndex;
            this.GridView1.DataSource = (new BLL.leibie()).GetAllList();
            this.GridView1.DataBind();
        }
    }
}
