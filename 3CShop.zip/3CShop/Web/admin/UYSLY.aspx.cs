﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class UYSLY : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "shan")
            {
                string mysql = "delete from productliuyan where lid='" + e.CommandArgument + "'";
                DataControl.Execute(mysql);
                Page.RegisterClientScriptBlock("e", "<script>alert('删除成功!');window.location.href=window.location.href;</script>");

            }
            else if (e.CommandName == "hui")
            {
                Response.Redirect("LYHF.aspx?id=" + e.CommandArgument);
            }
        }
    }
}
