﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class LYHF : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string mysql = "select * from productliuyan where lid='" + Request.QueryString["id"] + "'";
                DataTable  dr = DataControl.GetData(mysql);
                if (dr.Rows.Count>0)
                {
                    Label1.Text = dr.Rows[0]["liuzhu"].ToString();
                }

            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string mysql = "update productliuyan set liuhui='" + TextBox1.Text + "',huifutime='" + System.DateTime.Now + "'where lid='" + Request.QueryString["id"] + "'";
             DataControl.Execute(mysql);
            Label2.Visible = true;
            Label2.Text = "回复成功!";
        }
    }
}
