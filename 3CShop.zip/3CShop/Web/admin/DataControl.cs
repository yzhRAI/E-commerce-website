﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// DataBase 的摘要说明

/// </summary>
public class DataControl
{
    public DataControl()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}
    public static SqlConnection createConnection()
    {
        //从webconfig中取得字符串连接方式
        SqlConnection cnn = new SqlConnection(System.Configuration.ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        return cnn;
    }
    public static DataTable GetData(string SetStr )
    {
        //定义数据库连接 查询并填充DataSet

        SqlConnection tmpCnn = DataControl.createConnection();
        if (tmpCnn.State != 0)
        {
            tmpCnn.Close();
        }
        tmpCnn.Open();
        SqlDataAdapter cmd = new SqlDataAdapter(SetStr, tmpCnn);
        DataSet tmpDataSet = new DataSet();
        cmd.Fill(tmpDataSet);
        return tmpDataSet.Tables[0];
    }

    public static void Execute(string sqlStr)
    {
        //定义数据库连接　　执行数据库的增加　修改和删除数据的功能
        SqlConnection tmpCnn = DataControl.createConnection();
        if (tmpCnn.State != 0)
        {
            tmpCnn.Close();
        }
        tmpCnn.Open();

        SqlCommand cmd = new SqlCommand();
        cmd.CommandText = sqlStr;
        cmd.Connection = tmpCnn;
        cmd.ExecuteNonQuery();
    }

    public static string GetName(string Acount)
    {
        //根据传递的参数 检索当前的名称
        DataTable dt = new DataTable();
        if (Acount.Length > 6)
        {
            dt = DataControl.GetData("select * from 学生 where 用户名='" + Acount + "'");
            if (dt.Rows.Count > 0)
            {
                return "学生：" + dt.Rows[0]["姓名"].ToString();
            }
        } 
        else
        {
            dt = DataControl.GetData("select * from 教师 where 帐号='"+ Acount +"'");
            if (dt.Rows.Count > 0)
            {
                return "教师：" + dt.Rows[0]["姓名"].ToString();
            }
        }
            return "";
    }

    public static Int32 GetSTDM_STGLY(string ID)
    {
        //根据传递的参数 检索当前的名称
        DataTable dt = new DataTable();
        dt = DataControl.GetData("select * from 社团 where 社团管理员帐号='" + ID + "'");
            return  Convert.ToInt32(dt.Rows[0]["社团代码"]);
    }
}
