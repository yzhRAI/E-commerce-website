﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class OrD : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Panel1.Visible = false;
            xiugai();

        }
        public void xiugai()
        {

            string mysql = "select orders.*,orderdetail.* from orders,orderdetail where orders.oid='" + Request.QueryString["id"] + "'";
            DataTable  dr = DataControl.GetData(mysql);
            if (dr.Rows.Count>0)
            {
                Label1.Text = dr.Rows[0]["orderid"].ToString();
                Label2.Text = dr.Rows[0]["dingdanshijian"].ToString();
                Label3.Text = dr.Rows[0]["shouhuoname"].ToString();
                Label4.Text = dr.Rows[0]["address"].ToString();
                Label5.Text = dr.Rows[0]["postcode"].ToString();
                Label6.Text = dr.Rows[0]["telephone"].ToString();
                Label7.Text = dr.Rows[0]["songhuofs"].ToString();
                Label8.Text = dr.Rows[0]["fukuanfs"].ToString();
                Label9.Text = dr.Rows[0]["pid"].ToString();
                Label10.Text = dr.Rows[0]["dingdantotal"].ToString();
                Label11.Text = dr.Rows[0]["beizhu"].ToString();
                //MyGrid.DataSource = Class1.gd(mysql1);
                //MyGrid.DataBind();
            }
            string mysql1 = "select orderdetail.*,product.* from orderdetail,product where orderdetail.orderid='" + Label1.Text + "'and product.pid=orderdetail.pid";
            GridView1.DataSource = DataControl.GetData(mysql1);
            GridView1.DataBind();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            Button2.Visible = false;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string mysql1 = "update orders set dingdantotal='" + TextBox2.Text + "'where orderid='" + Label1.Text + "'";
            DataControl.Execute(mysql1);
                 Page.RegisterClientScriptBlock("e", "<script>alert('修改总价成功!')</script>");
                xiugai();
                Button2.Visible = true;
        }
    }
}
