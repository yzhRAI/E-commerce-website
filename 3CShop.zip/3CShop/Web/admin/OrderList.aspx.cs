﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace CAI.SHOP.Web
{
    public partial class OrderList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSourceID = "SqlDataSource1";
            }
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;
                Label label = (Label)e.Row.FindControl("zhuangtai");

                LinkButton lb = (LinkButton)e.Row.FindControl("geng");
                switch (drv["dingdanfeel"].ToString())
                {
                    case "0":
                        {
                            label.Text = "未确定订单";
                            lb.Text = "确定订单";
                            break;
                        }
                    case "1":
                        {
                            label.Text = "等待发货";
                            lb.Text = "商家发货";
                            break;
                        }
                    case "2":
                        {
                            label.Text = "商家已发货";
                            lb.Text = "收货确认";
                            lb.Enabled = false;
                            break;
                        }
                    case "3":
                        {
                            label.Text = "确认收货";
                            lb.Text = "完成交易";
                            break;
                        }
                    case "4":
                        {
                            label.Text = "完成交易";
                            lb.Text = "交易完成";
                            lb.Enabled = false;
                            break;
                        }
                }
            }
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "cao")
            {
                GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
                string orderid = (row.Cells[0].FindControl("label2") as Label).Text;
                string dingdan = (row.Cells[0].FindControl("ding") as Label).Text;
                string user = (row.Cells[0].FindControl("label3") as Label).Text;
                int userji = Convert.ToInt32((row.Cells[0].FindControl("label4") as Label).Text);

                switch (dingdan)
                {
                    case "0":
                        {
                            string mysql = "update orders set dingdanfeel=1 where orderid='" + orderid + "'";
                             DataControl.Execute(mysql);
                            GridView1.DataSourceID = "SqlDataSource1";
                            break;
                        }
                    case "1":
                        {

                            string tcontent = "您好," + user.ToString() + ",您在本公司订购的商品,订单号为" + orderid.ToString() + "的商品,已经成功发货了!IT数码商城多谢你的支持,祝您购物愉快!";
                            string mysql = "update orders set dingdanfeel=2 where orderid='" + orderid + "';insert into pxiaoxi(pcontent,userid)values('" + tcontent + "','" + user + "')";
                            DataControl.Execute(mysql);
                            GridView1.DataSourceID = "SqlDataSource1";
                            break;
                        }
                    case "3":
                        {
                            //string mysql1 = "select * from orderdetail where orderid='" + orderid + "'";
                            //DataTable  dr = DataControl.GetData(mysql1);
                            //if (dr.Read())
                            //{
                            //    string gcontent = "您好， " + user + ",您在本公司订购的商品，订单号为" + orderid + "的商品,已经交易成功了!IT数码商城将送您" + userji + "积分！多谢你的支持,祝您购物愉快！";
                            //    int n = Convert.ToInt32(dr["pid"].ToString());
                            //    string mysql = "update orders set dingdanfeel=4 where orderid='" + orderid + "';update product set pkc=pkc-1 where product.pid='" + n + "';update d_users set userjifen=userjifen+'" + userji + "' where username='" + user + "';insert into pxiaoxi(pcontent,userid)values('" + gcontent + "','" + user + "')";
                            //    DataControl.Execute(mysql);
                            //    GridView1.DataSourceID = "SqlDataSource1";

                            //}
                            break;
                        }


                }
            }
            else if (e.CommandName == "del")
            {
                // Label pid = (Label)e.Item.FindControl("pid");
                //int piid = Convert.ToInt32(pid.Text);
                string mysql = "delete from orders where orderid='" + e.CommandArgument.ToString() + "'";
              
                    Page.RegisterClientScriptBlock("e", "<script>alert('删除成功!')</script>");
                    GridView1.DataSourceID = "SqlDataSource1";
             }
        }
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (DropDownList1.SelectedValue)
            {
                case "0":
                    {
                        GridView1.DataSourceID = "SqlDataSource2";
                        break;
                    }
                case "1":
                    {
                        GridView1.DataSourceID = "SqlDataSource2";
                        break;
                    }
                case "2":
                    {
                        GridView1.DataSourceID = "SqlDataSource2";
                        break;
                    }
                case "3":
                    {
                        GridView1.DataSourceID = "SqlDataSource2";
                        break;
                    }
                case "4":
                    {
                        GridView1.DataSourceID = "SqlDataSource2";
                        break;
                    }
                case "5":
                    {
                        GridView1.DataSourceID = "SqlDataSource1";
                        break;
                    }

            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {

            if (TextBox3.Text == "")
            {
                Page.RegisterClientScriptBlock("e", "<script>alert('请输入用户名!')</script>");
                GridView1.DataSourceID = "SqlDataSource1";
            }
            else
            {
                GridView1.DataSourceID = "SqlDataSource3";
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {

        }
        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {



        }
    }
}
