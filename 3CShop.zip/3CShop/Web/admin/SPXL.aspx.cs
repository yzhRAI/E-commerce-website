﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class SPXL : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 在此处放置用户代码以初始化页面


            if (!Page.IsPostBack)
            {
                rdLB.DataTextField = "Classname";
                rdLB.DataValueField = "Classid";
                rdLB.DataSource = (new BLL.leibie()).GetAllList();
                rdLB.DataBind();

                if (Request.QueryString["ID"] != null)
                {
                    //显示当前的商品信息
                    DataTable tmpda = new DataTable();
                    tmpda = (new BLL.leibiex()).GetList("  Classxid=" + Request.QueryString["ID"]).Tables[0];
                    if (tmpda.Rows.Count > 0)
                    {
                        this.txtSPMC.Text = tmpda.Rows[0]["Classxname"].ToString();
                        this.rdLB.SelectedValue = tmpda.Rows[0]["Classid"].ToString();

                    }
                }
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //判断信息是否正确
            if (this.txtSPMC.Text.Trim() == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('类别名称不能为空！');</script>");
                return;
            }


            //根据标志判断是添加还是修改的操作 保存商品信息

            Model.leibiex yy = new Model.leibiex();
            yy.Classid = int.Parse(this.rdLB.SelectedValue);
            yy.Classxname = this.txtSPMC.Text;

            if (Request.QueryString["ID"] != null)
            {
                yy.Classxid = Convert.ToInt32(Request.QueryString["ID"]);
                (new BLL.leibiex()).Update(yy);
            }
            else
            {
                (new BLL.leibiex()).Add(yy);

            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存成功！');window.location.href='SPXLList.aspx';</script>");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            //跳转页面
            Response.Redirect("SPXLList.aspx");
        }
    }
}
