﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

namespace CAI.SHOP.Web.admin
{
    public partial class SPXX : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            // 在此处放置用户代码以初始化页面
            if (!Page.IsPostBack)
            {
                Session.Remove("imgname");
                if (Request.QueryString["ID"] != null)
                {
                    //显示当前的商品信息
                    Model.product prd = (new  BLL.product()).GetModel(Int32.Parse( Request.QueryString["ID"]));
                    if (prd !=null)
                    {
                        this.DropDownList1.SelectedValue = prd.classid.ToString();

                        DropDownList2.DataTextField = "classxname";
                        DropDownList2.DataValueField = "classxid";
                        DropDownList2.DataSource = (new BLL.leibiex()).GetList(" Classid=" + prd.classid.ToString());
                        DropDownList2.DataBind();

                        this.DropDownList2.SelectedValue = prd.classxid.ToString();
                        txtSPMC.Text = prd.productname;
                        txtSPJG.Text = prd.masterprice.ToString();
                        txtRMJ.Text = prd.hotprice.ToString();
                        txtKC.Text = prd.pkc.ToString();
                        txtGJZ.Text = prd.productguanjian;
                        txtSPPP.Text = prd.productchu;
                        txtSPGG.Text = prd.guige;
                        txtJF.Text = prd.jifen.ToString();
                        txtSPZP.Text = prd.zenpin;
                        DropDownList3.SelectedIndex =prd.newproduct;
                        txtXXSM.Text = prd.productintroduce;
                        this.Image1.ImageUrl = "../" + prd.productimage.ToString();
                        Session["imgname"] = prd.productimage.ToString();


                    }
                }
            }

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //判断信息是否正确
            if (this.txtSPMC.Text.Trim() == "")
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('商品名称不能为空！');</script>");
                return;
            }

            //将相关的图片上传到@"Image\"路径下
            string FileName = "";
            string FileName1;
            string DPath;
            DPath = Server.MapPath("..") + @"\";
            DPath = DPath + @"pic\";
            if (this.File1.PostedFile.FileName != "")
            {
                string[] temp = this.File1.PostedFile.FileName.Split('.');
                string strHzm = "." + temp[temp.Length - 1];

                Guid tmp = Guid.NewGuid();
                FileName = tmp.ToString() + strHzm;
                FileName1 = DPath + tmp.ToString() + strHzm;
                this.File1.PostedFile.SaveAs(FileName1);
                if (Session["imgname"] != null)
                {
                    if (File.Exists(DPath + Session["imgname"].ToString()))
                    {
                        File.Delete(DPath + Session["imgname"].ToString());
                    }
                }
            }

            //根据标志判断是添加还是修改的操作 保存商品信息

            Model.product prd = new Model.product();
            prd.classid=int.Parse(this.DropDownList1.SelectedValue);
            prd.classxid = int.Parse(this.DropDownList2.SelectedValue);
            prd.productname=txtSPMC.Text;
            prd.masterprice=Decimal.Parse( txtSPJG.Text);
            prd.hotprice = Decimal.Parse(txtRMJ.Text);
            prd.pkc = int.Parse(txtKC.Text);
            prd.productguanjian=txtGJZ.Text;
            prd.productchu=txtSPPP.Text;
            prd.guige=txtSPGG.Text;
            prd.jifen = int.Parse(txtJF.Text);
            prd.zenpin=txtSPZP.Text;
            prd.newproduct = DropDownList3.SelectedIndex;
            prd.productintroduce=txtXXSM.Text;
            if (FileName != "")
            {
                prd.productimage = "pic\\" + FileName; 
            }
            else
            {
                prd.productimage = this.Image1.ImageUrl;
            }

            if (Request.QueryString["ID"] != null)
            {
                prd.pid = Convert.ToInt32(Request.QueryString["ID"]);
                (new BLL.product()).Update(prd);
            }
            else
            {
                (new BLL.product()).Add(prd);

            }
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('保存成功！');window.location.href='SPXXList.aspx';</script>");
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            //跳转页面
            Response.Redirect("SPXXList.aspx");
        }


        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList2.DataSource = (new BLL.leibiex()).GetList(" Classid=" + this.DropDownList1.SelectedValue);
            DropDownList2.DataTextField = "classxname";
            DropDownList2.DataValueField = "classxid";
            //  DropDownList2.SelectedValue = dr["classxid"].ToString();
            DropDownList2.DataBind();
        }


    }
}
