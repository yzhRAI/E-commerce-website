﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web.admin
{
    public partial class UpdatePwd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // 在此处放置用户代码以初始化页面
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (this.TextBox1.Text.Trim() != this.Textbox2.Text.Trim())
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('密码不一致！');</script>");
                return;
            }


            Model.admin model = new Model.admin();
            model.adminname = "admin";
            model.password = TextBox1.Text;

            BLL.admin bll = new BLL.admin();
            bll.Update(model);
            Page.ClientScript.RegisterStartupScript(this.GetType(), "info", "<script>alert('修改完成！');</script>");

        }
    }
}
