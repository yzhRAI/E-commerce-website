﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;


using System.Drawing;
using System.Drawing.Imaging;
using System.IO;


public partial class ValidateCode : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            string str_RandomNumber = this.GetRandomNumberString(4);
            Session["ValidateCode"] = str_RandomNumber;
            this.CreateImage(str_RandomNumber);
        }
    }

    //产生随机数的方法
    public string GetRandomNumberString(int int_NumberLength)
    {
        string str_Number = string.Empty;
        Random theRandomNumber = new Random();

        for (int int_index = 0; int_index < int_NumberLength; int_index++)
            str_Number += theRandomNumber.Next(10).ToString();

        return str_Number;
    }

    //生成字体颜色的方法
    public Color GetRandomColor()
    {
        Random RandomNum_First = new Random((int)DateTime.Now.Ticks);
        //  对于C#的随机数，没什么好说的
        System.Threading.Thread.Sleep(RandomNum_First.Next(50));
        Random RandomNum_Sencond = new Random((int)DateTime.Now.Ticks);

        //  为了在白色背景上显示，尽量生成深色
        int int_Red = RandomNum_First.Next(256);
        int int_Green = RandomNum_Sencond.Next(256);
        int int_Blue = (int_Red + int_Green > 400) ? 0 : 400 - int_Red - int_Green;
        int_Blue = (int_Blue > 255) ? 255 : int_Blue;

        return Color.FromArgb(int_Red, int_Green, int_Blue);
    }

    public void CreateImage(string str_ValidateCode)
    {
        int int_ImageWidth = str_ValidateCode.Length * 13;
        Random newRandom = new Random();
        //  图高20px
        Bitmap theBitmap = new Bitmap(int_ImageWidth, 20);
        Graphics theGraphics = Graphics.FromImage(theBitmap);
        //  白色背景
        theGraphics.Clear(Color.White);
        //  灰色边框
        theGraphics.DrawRectangle(new Pen(Color.LightGray, 1), 0, 0, int_ImageWidth - 1, 19);

        //  10pt的字体
        Font theFont = new Font("Arial", 10);

        for (int int_index = 0; int_index < str_ValidateCode.Length; int_index++)
        {
            string str_char = str_ValidateCode.Substring(int_index, 1);
            Brush newBrush = new SolidBrush(GetRandomColor());
            Point thePos = new Point(int_index * 13 + 1 + newRandom.Next(3), 1 + newRandom.Next(3));
            theGraphics.DrawString(str_char, theFont, newBrush, thePos);
        }

        //  将生成的图片发回客户端
        MemoryStream ms = new MemoryStream();
        theBitmap.Save(ms, ImageFormat.Png);

        Response.ClearContent(); //需要输出图象信息 要修改HTTP头 
        Response.ContentType = "image/Png";
        Response.BinaryWrite(ms.ToArray());
        theGraphics.Dispose();
        theBitmap.Dispose();
        Response.End();
    }

}
