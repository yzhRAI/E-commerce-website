﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class myshoucang : System.Web.UI.Page
    {
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.BLL.shoucang shoucangbll = new CAI.SHOP.BLL.shoucang();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["username"] == null)
                {
                    Response.Redirect("ssnotice.aspx");
                }
                else
                {
                    fenye();
                    if (DataList1.Items.Count == 0)
                    {
                        Label4.Visible = true;
                        Label4.Text = "暂时没有相关的数据";
                    }
                }
            }
        }
        public void fenye()
        {
            DataSet ds = productbll.GetList("pid in(select pid from shoucang where username='" + Session["username"] + "')");
            //string mysqlba = "SELECT  product.*,shoucang.* from product,shoucang WHERE (product.pid=shoucang.pid)and(username='" + Session["username"] + "')";
            DataView dv =ds.Tables[0].DefaultView;
            PagedDataSource pds = new PagedDataSource();

            AspNetPager1.RecordCount = dv.Count;
            pds.DataSource = dv;
            pds.AllowPaging = true;
            pds.CurrentPageIndex = AspNetPager1.CurrentPageIndex - 1;
            pds.PageSize = AspNetPager1.PageSize;
            this.DataList1.DataSource = pds;
            this.DataList1.DataBind();


        }
        protected void DataList1_ItemDataBound(object sender, DataListItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)

            //if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //  TextBox TXT = (TextBox)e.Item.FindControl("quantity");
                // TXT.Text = "1";
                LinkButton lik = (LinkButton)e.Item.FindControl("LinkButton1");
                LinkButton lig = (LinkButton)e.Item.FindControl("LinkButton2");
                lik.Text = @"<img src='images/goumai1.bmp' border='0'>";
                lig.Text = @"<img src='images/gouche.gif' border='0'>";
            }
        }
        protected void AspNetPager1_PageChanged(object sender, EventArgs e)
        {
            fenye();
        }
        protected void DataList1_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName == "like")
            {
                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }
                Session["Car"] = hash;
                //  Response.Write("<script>window.open('shoppingcar.aspx');</script>");
                Response.Redirect("shoppingcar.aspx");
            }
            else if (e.CommandName == "jiaru")
            {

                Hashtable hash;
                if (Session["Car"] == null)
                {
                    //如果用户没有分配购物车
                    hash = new Hashtable();         //新生成一个
                    //  hash.Add(e.CommandArgument, 1); //添加一个商品
                    // Session["Cart"] = hash;     //分配给用户
                }
                else
                {
                    //用户已经有购物车
                    hash = (Hashtable)Session["Car"];//得到购物车的hash表
                }
                if (!hash.Contains(e.CommandArgument))//购物车中已有此商品，商品数量加1
                {
                    hash.Add(e.CommandArgument, 1);//如果没有此商品，则新添加一个项

                }
                else
                {
                    int count = Convert.ToInt32(hash[e.CommandArgument].ToString());//得到该商品的数量
                    hash[e.CommandArgument] = (count + 1);//商品数量加1
                }
                Session["Car"] = hash;
            }
            else if (e.CommandName == "del")
            {
                Label pid = (Label)e.Item.FindControl("pid");
                int piid = Convert.ToInt32(pid.Text);
                DataSet ds=shoucangbll.GetList("pid='"+piid+"'");
                string sid=ds.Tables[0].Rows[0]["sid"].ToString();
             //   CAI.SHOP.Model.shoucang shoucangmodel=shoucangbll.GetModel()

                int n = shoucangbll.Delete(Convert.ToInt32(sid));
               
                if (n > 0)
                {
                    LTP.Common.MessageBox.Show(this, "删除成功");
                    fenye();

                 // Page.RegisterClientScriptBlock("e", "<script>alert('删除成功!');location.href='myshoucang.aspx'</script>");
                }
            }
        }
    }
}
