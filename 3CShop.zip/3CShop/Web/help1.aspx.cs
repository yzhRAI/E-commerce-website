﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class help1 : System.Web.UI.Page
    {
        CAI.SHOP.BLL.help2 help2bll = new CAI.SHOP.BLL.help2();
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                Shownetinfo();

                if(Request.QueryString["id"]!=null)
                {
                DataSet dsa = help2bll.GetList("hhid='" + Request.QueryString["id"] + "'");
              
                    Label3.Visible = false;
                    Label2.Visible = true;
                    Label2.Text =dsa.Tables[0].Rows[0]["helpdetail"].ToString();


                }
                else
                {
                    Label3.Visible = true;
                    Label2.Visible = false;


                }
            }

        }

        public DataSet Getfromxlm()
        {
            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(MapPath("~/helpkefu.xml"));
            }
            catch
            {
                Response.Write("<Script>alert('信息文件丢失！')</Script>");
            }
            return ds;
        }
        private void Shownetinfo()
        {
            DataSet ds = new DataSet();
            ds = Getfromxlm();

            //Label4.Text = ds.Tables[0].Rows[0][0].ToString();
            //Label5.Text = ds.Tables[0].Rows[0][1].ToString();
            //Label6.Text = ds.Tables[0].Rows[0][2].ToString();
            Label3.Text = ds.Tables[0].Rows[0][3].ToString();
            // Label4.Text = ds.Tables[0].Rows[0][3].ToString();
            //Label5.Text = ds.Tables[0].Rows[0][4].ToString();

        }
        protected void DataList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
