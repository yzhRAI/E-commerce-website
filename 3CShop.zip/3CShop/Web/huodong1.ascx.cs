﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class huodong1 : System.Web.UI.UserControl
    {

        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.Model.product productmodel = new CAI.SHOP.Model.product();
        CAI.SHOP.BLL.productliuyan liuyanbll = new CAI.SHOP.BLL.productliuyan();
        CAI.SHOP.Model.productliuyan liuyanmodel = new CAI.SHOP.Model.productliuyan();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                 DataSet ds = productbll.GetList("pid='" + Request.QueryString["id"] + "'");
                  Label1.Text =ds.Tables[0].Rows[0]["productintroduce"].ToString();
                
            
            }

        }

        public void jilu()
        {



        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("ssnotice.aspx");
            }
            else
            {
                liuyanmodel.pid =Convert.ToInt32(Request.QueryString["id"].ToString());
                liuyanmodel.liuname = Session["username"].ToString();
                liuyanmodel.liutime = System.DateTime.Now;
                liuyanmodel.liuzhu = TextBox1.Text;
                liuyanbll.Add(liuyanmodel);
               
                //Response.Write("<script>alert('发表成功');location.href='productdetail.aspx?id="+Request.QueryString["id"]+"'</script>");
                GridView1.DataSourceID = "SqlDataSource3";
                TextBox1.Text = "";
                //  Server.Transfer("productdetail.aspx?id="+Request.QueryString["id"]);
                // Panel2.Visible = true;
            }
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
        }
    }
}