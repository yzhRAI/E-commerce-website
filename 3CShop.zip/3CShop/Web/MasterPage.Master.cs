﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class MasterPage : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void imgBtnLogin_Click1(object sender, ImageClickEventArgs e)
        {

        }
        protected void DropDownList1_Init(object sender, EventArgs e)
        {
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {

           
        }
    }
}
