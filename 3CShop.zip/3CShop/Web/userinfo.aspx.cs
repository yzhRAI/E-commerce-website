﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class userinfo : System.Web.UI.Page
    {
        CAI.SHOP.BLL.d_users userbll = new CAI.SHOP.BLL.d_users();
        CAI.SHOP.Model.d_users usermodel = new CAI.SHOP.Model.d_users();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                DataSet ds = userbll.GetList("username='" + Session["username"].ToString() + "'");
           
                    TextBox1.Text =ds.Tables[0].Rows[0]["username"].ToString();
                    TextBox2.Text = ds.Tables[0].Rows[0]["regdate"].ToString();
                    TextBox3.Text = ds.Tables[0].Rows[0]["email"].ToString();
                    TextBox4.Text = ds.Tables[0].Rows[0]["qq"].ToString();
                    TextBox5.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                    TextBox6.Text = ds.Tables[0].Rows[0]["Postcode"].ToString();
                    TextBox7.Text = ds.Tables[0].Rows[0]["Telephone"].ToString();
                    TextBox8.Text = ds.Tables[0].Rows[0]["question"].ToString();
                    TextBox9.Text = ds.Tables[0].Rows[0]["answer"].ToString();
                    string uid = ds.Tables[0].Rows[0]["uid"].ToString();
                    Label3.Text = uid;
               
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
             usermodel.uid =Convert.ToInt32(Label3.Text.ToString());
             usermodel.username=TextBox1.Text.ToString();
             usermodel.regdate=Convert.ToDateTime(TextBox2.Text.ToString());
             usermodel.email=TextBox3.Text.ToString();
             usermodel.QQ=TextBox4.Text.ToString();
             usermodel.Address=TextBox5.Text.ToString();
             usermodel.Postcode=TextBox6.Text.ToString();
             usermodel.Telephone=TextBox7.Text.ToString();
             usermodel.question=TextBox8.Text.ToString();
             usermodel.answer=TextBox9.Text.ToString();
             int n = userbll.Update(usermodel);
            //string mysql1 = "update d_users set username='" + TextBox1.Text + "',regdate='" + TextBox2.Text + "',email='" + TextBox3.Text + "',qq='" + TextBox4.Text + "',Address='" + TextBox5.Text + "',Postcode='" + TextBox6.Text + "',Telephone='" + TextBox7.Text + "',question='" + TextBox8.Text + "',answer='" + TextBox9.Text + "'";
            //int n = Class1.exexu(mysql1);
            if (n > 0)
            {
                Label1.Visible = true;

                Label1.Text = "修改个人信息成功!";
                //  Response.Write("<script>alert('修改商品成功')</script>");
                // Server.Transfer("editbankuaigx.aspx?id=" + Request.QueryString["id"]);
            }
           
        }
    }
}
