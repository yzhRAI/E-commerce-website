﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using System.Data.SqlClient;
/// <summary>
/// Class1 的摘要说明
/// </summary>
public class Class1
{
	public Class1()
	{
		//
		// TODO: 在此处添加构造函数逻辑
		//
	}

    public  static string lianjie()
    {
        string connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
        return connstr;

    
    
    }
    public  static int dd(string sql)// executescalar类

    { 
   SqlConnection conn=new SqlConnection();
    conn.ConnectionString = lianjie();
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        int tm=(int)(cmd.ExecuteScalar());
        conn.Close();
       // int t;
        //t = Convert.ToInt32(cmd);
        return tm;
    
    }
    public static int exexu(string sql)
    {
       SqlConnection conn=new SqlConnection(lianjie());
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
       int n=cmd.ExecuteNonQuery();
        conn.Close();
        return n;
    
    }
    public  static   void  pd()//判断类！

    {
        if (System.Web.HttpContext.Current.Session["admin"] == null)
        {
            System.Web.HttpContext.Current.Response.Write("<script>alert('对不起，还没有登陆，请登陆！')</script>");
        }
    }
        public static  DataSet  gd(string sql)//数据集绑定类
        {
            SqlConnection conn = new  SqlConnection(lianjie());
            conn.Open();
            SqlCommand cmd =new SqlCommand(sql,conn);
            SqlDataAdapter ada=new SqlDataAdapter(cmd);
            DataSet ds=new DataSet();
            ada.Fill(ds);
           
            return ds;
           conn.Close();
        }
    public static SqlDataReader sqrea(string sql)//sqldatareader读取类
    {
        SqlConnection conn = new SqlConnection(lianjie());
        conn.Open();
        SqlCommand cmd = new SqlCommand(sql, conn);
        
        return  cmd.ExecuteReader();
        conn.Close();
       
    }
     
}
