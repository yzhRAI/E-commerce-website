﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class dingdanxiangxi : System.Web.UI.Page
    { 
         CAI.SHOP.BLL.orders ordersbll = new CAI.SHOP.BLL.orders();
         CAI.SHOP.BLL.orderdetail orderdetailbll = new CAI.SHOP.BLL.orderdetail();
         CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        protected void Page_Load(object sender, EventArgs e)
        {

            sss();
        }
        public void sss()
        {
            string ooid=Request.QueryString["id"].ToString();

            CAI.SHOP.Model.orders ordersmodel = ordersbll.GetModel(Convert.ToInt32(ooid));

           // CAI.SHOP.Model.orderdetail orderdetailmodel = orderdetailbll.GetModel(Convert.ToInt32(ooid));
            //string mysql = "select orders.*,orderdetail.* from orders,orderdetail where orders.oid='" + Request.QueryString["id"] + "'";
            //SqlDataReader dr = Class1.sqrea(mysql);
            //if (dr.Read())
            //{
            Label1.Text = ordersmodel.orderid;
            DateTime shijian = Convert.ToDateTime(ordersmodel.dingdanshijian.ToString());

            Label2.Text = shijian.ToString();
            Label3.Text = ordersmodel.shouhuoname;
            Label4.Text = ordersmodel.address;  
            Label5.Text = ordersmodel.postcode;

            Label6.Text = ordersmodel.telephone; 
            Label7.Text = ordersmodel.songhuofs; 
            Label8.Text = ordersmodel.fukuanfs; 

              //  Label9.Text =ordersmodel.p dr["pid"].ToString();
            Label10.Text = ordersmodel.beizhu;
            string dingdanfeel =ordersmodel.dingdanfeel.ToString();
            int  df=Convert.ToInt32(dingdanfeel);
 
                //  string dfell = dr["dingdanfeel"].ToString();
                switch (df.ToString())
                {
                    case "0":
                        {
                            Label11.Text = "未确定订单";

                            break;
                        }
                    case "1":
                        {
                            Label11.Text = "等待发货";
                            break;
                        }
                    case "2":
                        {

                            Label11.Text = "商家已发货";

                            break;
                        }
                    case "3":
                        {
                            Label11.Text = "确认收货";

                            break;
                        }
                    case "4":
                        {

                            Label11.Text = "完成交易";

                            break;
                        }
                }
                decimal dtotal = Convert.ToDecimal(ordersmodel.dingdantotal.ToString());
                Label13.Text = dtotal.ToString();
                //MyGrid.DataSource = Class1.gd(mysql1);
                //MyGrid.DataBind();
            //}
                DataSet ds = productbll.GetTwoList(Label1.Text);
           // string mysql1 = "select orderdetail.*,product.* from orderdetail,product where orderdetail.orderid='" + Label1.Text + "'and product.pid=orderdetail.pid";
                GridView1.DataSource = ds;
            GridView1.DataBind();

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("pay2.aspx?id=" + Request.QueryString["id"].ToString());
        }
    }
}
