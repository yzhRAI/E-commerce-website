﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class Test : System.Web.UI.Page
    {
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        protected void Page_Load(object sender, EventArgs e)
        {
           
           
            DataSet ds = productbll.GetList(5, "classxid=12", "adddate desc");
            DataList8.DataSource = ds;
          
      
            DataList8.DataBind();
        }

        protected void DataList8_ItemCommand(object source, DataListCommandEventArgs e)
        {

        }

        protected void DataList8_ItemDataBound(object sender, DataListItemEventArgs e)
        {

        }
    }
}
