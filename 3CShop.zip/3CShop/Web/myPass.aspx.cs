﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
namespace CAI.SHOP.Web
{
    public partial class Pass : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string connstr = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();

            string mysql = "update d_users set password='" + TextBox1.Text + "'where username='" + Session["username"].ToString() + "'";
            SqlConnection conn = new SqlConnection(connstr);
            conn.Open();
            SqlCommand cmd = new SqlCommand(mysql, conn);
            int n = cmd.ExecuteNonQuery();
            conn.Close();
            if (n > 0)
            {
                Label1.Visible = true;
                Label1.Text = "修改密码成功!";
                //  Response.Write("<script>alert('修改产品成功')</script>");
                // Server.Transfer("editbankuaigx.aspx?id=" + Request.QueryString["id"]);
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "修改密码失败!";
            }
        }
    }
}