﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class mydingdan : System.Web.UI.Page
    {
        CAI.SHOP.BLL.orders orderbll = new CAI.SHOP.BLL.orders();
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        protected void Page_Load(object sender, EventArgs e)
        {
            bindyy();
        }

        public void bindyy()
        {

            DataSet ds = orderbll.GetList("username='" + Session["username"] + "' order by dingdanshijian desc");
            GridView1.DataSource = ds;
            GridView1.DataBind();

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView drv = e.Row.DataItem as DataRowView;
                Label label = (Label)e.Row.FindControl("zhuangtai");

                LinkButton lb = (LinkButton)e.Row.FindControl("geng");
                switch (drv["dingdanfeel"].ToString())
                {
                    case "0":
                        {
                            label.Text = "未确定订单";
                            lb.Text = "确定订单";
                            break;
                        }
                    case "1":
                        {
                            label.Text = "等待发货";
                            lb.Text = "取消订单";
                            break;
                        }
                    case "2":
                        {
                            label.Text = "商家已发货";
                            lb.Text = "确认收货";
                            break;
                        }
                    case "3":
                        {
                            label.Text = "确认收货";
                            lb.Text = "等待完成";
                            lb.Enabled = false;
                            break;
                        }
                    case "4":
                        {
                            label.Text = "完成交易";
                            lb.Text = "交易完成";
                            lb.Enabled = false;
                            break;
                        }
                }
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridViewRow row = (GridViewRow)((Control)e.CommandSource).Parent.Parent;
            string oid = (row.Cells[0].FindControl("label3") as Label).Text;
            string dingdan = (row.Cells[0].FindControl("ding") as Label).Text;

            if (e.CommandName == "cao")
            {
                //string lab = ((Label)GridView1.Rows[e.RowIndex].Cells[列号].FindControl("Label1")).Text;
                // string ddd=((Label)GridView1.Rows[e.r])

                switch (dingdan)
                {
                    case "0":
                        {
                            CAI.SHOP.Model.orders ordermodel = orderbll.GetModel(Convert.ToInt32(oid));
                            ordermodel.dingdanfeel = 1;
                            orderbll.Update(ordermodel);
                            //string mysql = "update orders set dingdanfeel=1 where orderid='" + orderid + "'";
                            //Class1.exexu(mysql);
                            //GridView1.DataSourceID = "SqlDataSource1";
                            bindyy();
                            break;
                        }
                    case "1":
                        {

                            CAI.SHOP.Model.orders ordermodel = orderbll.GetModel(Convert.ToInt32(oid));
                            ordermodel.dingdanfeel = 0;
                            orderbll.Update(ordermodel);
                            //string mysql = "update orders set dingdanfeel=0 where orderid='" + orderid + "'";
                            //Class1.exexu(mysql);
                            // GridView1.DataSourceID = "SqlDataSource1";
                            bindyy();
                            break;
                        }
                    case "2":
                        {

                            CAI.SHOP.Model.orders ordermodel = orderbll.GetModel(Convert.ToInt32(oid));
                            ordermodel.dingdanfeel = 3;
                            orderbll.Update(ordermodel);
                            //string mysql = "update orders set dingdanfeel=3 where orderid='" + orderid + "'";
                            //Class1.exexu(mysql);
                            //GridView1.DataSourceID = "SqlDataSource1";
                            bindyy();
                            break;
                        }


                }


            }
            else if (e.CommandName == "del")
            {
                // Label pid = (Label)e.Item.FindControl("pid");
                //int piid = Convert.ToInt32(pid.Text);

                int n = orderbll.Delete(Convert.ToInt32(oid));
                //string mysql = "delete from orders where orderid='" + e.CommandArgument.ToString() + "'";
                //int n = Class1.exexu(mysql);
                if (n > 0)
                {
                    LTP.Common.MessageBox.Show(this, "删除成功！");
                    bindyy();
                    //Page.RegisterClientScriptBlock("e", "<script>alert('删除成功!')</script>");
                    // GridView1.DataSourceID = "SqlDataSource1";
                }
            }
        }

    }
}
