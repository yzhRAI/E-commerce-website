﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class userzhuce : System.Web.UI.Page
    {
        CAI.SHOP.BLL.d_users userbll = new CAI.SHOP.BLL.d_users();
        CAI.SHOP.Model.d_users usermodel = new CAI.SHOP.Model.d_users();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Shownetinfo();
            }
        }

        public DataSet Getfromxlm()
        {
            DataSet ds = new DataSet();
            try
            {
                ds.ReadXml(MapPath("admin/zhuce.xml"));
            }
            catch
            {
                Response.Write("<Script>alert('信息文件丢失！')</Script>");
            }
            return ds;
        }
        private void Shownetinfo()
        {
            DataSet ds = new DataSet();
            ds = Getfromxlm();
            TextBox8.Text = ds.Tables[0].Rows[0][0].ToString();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "")
            {
                Page.RegisterClientScriptBlock("e", "<script>alert('用户名不能为空！')</script>");
            }
            else
            {
                bool n = userbll.Exists(TextBox1.Text);
               if(n)
                {
                    TextBox1.Focus();
                    Label1.Visible = true;
                    Label1.Text = "该用户已经存在！";
                    //  Page.RegisterClientScriptBlock("e","<script language='javascript'>alert('该用户已经存在！')</script>");

                }
                else
                {
                    Label1.Visible = true;
                    Label1.Text = "用户名可用";
                    //Page.RegisterClientScriptBlock("e","<script>alert('用户名可用')</script>");
                }
            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string strValidate = TextBox7.Text;
            string strRandom = Session["ValidateCode"].ToString();

            if (strValidate == strRandom)
            {
                usermodel.username = TextBox1.Text.ToString();
                usermodel.password = TextBox2.Text.ToString();
              
                usermodel.email = TextBox4.Text.ToString();
                usermodel.question = DropDownList1.SelectedValue.ToString(); 
                usermodel.answer = TextBox6.Text.ToString();
                usermodel.regdate = System.DateTime.Now;
                usermodel.lastloginip = Request.UserHostAddress;
                int n = userbll.Add(usermodel);
                if (n > 0)
                {
                    Session["username"] = TextBox1.Text;
                    Response.Write("<script>alert('恭喜您,注册成功啦!');location.href='default.aspx'</script>");
                    // Server.Transfer("default.aspx");

                }
            }
            else
            {


                Page.RegisterClientScriptBlock("e", "<script>alert('验证码错误')</script>");

                return;
            }
        }
        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
