﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class top : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (Session["username"] == null)
                {
                    HyperLink5.Visible = false;
                    LinkButton1.Visible = false;
                }
                else
                {
                    HyperLink5.Visible = true;
                    HyperLink5.Text = Session["username"].ToString() + ",";
                    HyperLink1.Visible = false;
                    LinkButton1.Visible = true;
                    // HyperLink2.Visible = false;

                }
            }
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Session["username"] = null;
            //  Response.Write("<script>alert('恭喜你，成功退出!');location.href='default.aspx'</script>");
            Response.Redirect("default.aspx");
        }
    }
}