﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class usermanage : System.Web.UI.MasterPage
    {
        CAI.SHOP.BLL.pxiaoxi pxiaoxibll = new CAI.SHOP.BLL.pxiaoxi();
        CAI.SHOP.BLL.d_users userbll = new CAI.SHOP.BLL.d_users();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("ssnotice.aspx");
            }
            else
            {
                Label1.Text = Session["username"].ToString();

                gg();
                gga();
            }


        }

        public void gga()
        {
            string username=Session["username"].ToString();
            int n = pxiaoxibll.dscount(username);
            
          //  string mysql1 = "select count(*) from pxiaoxi where userid='" + Session["username"].ToString() + "'and pfeel=0";
            //int n = Class1.dd(mysql1);
            LinkButton1.Text = n.ToString();
            
        }

        public void gg()
        {

            DataSet ds = userbll.GetList("username='" + Session["username"].ToString() + "'");
           //// string mysql1 = "select * from d_users where username='" + Session["username"].ToString() + "'";

           // SqlDataReader dr = Class1.sqrea(mysql1);
           // if (dr.Read())
           // {
                Label2.Text =ds.Tables[0].Rows[0]["userjifen"].ToString();



            //}
        }
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (TextBox1.Text == "")
            {
                Page.RegisterClientScriptBlock("e", "<script>alert('请输入关键字!')</script>");
            }
            else
            {
                Response.Redirect("search.aspx?productname=" + TextBox1.Text);
            }
        }
        protected void LinkButton1_Click(object sender, EventArgs e)
        {

        }
    }
}
