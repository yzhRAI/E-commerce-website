﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections.Generic;
using System.Xml.Linq;

namespace CAI.SHOP.Web
{
    public partial class pay1 : System.Web.UI.Page
    {
        Double TtlPrice;
        Double jifena;
        CAI.SHOP.BLL.product productbll = new CAI.SHOP.BLL.product();
        CAI.SHOP.BLL.d_users userbll = new CAI.SHOP.BLL.d_users();
        CAI.SHOP.Model.d_users usermodel = new CAI.SHOP.Model.d_users();
        CAI.SHOP.BLL.orders ordersbll=new CAI.SHOP.BLL.orders();
        CAI.SHOP.Model.orders ordersmodel=new CAI.SHOP.Model.orders();
        CAI.SHOP.Model.orderdetail orderdetailmodel=new CAI.SHOP.Model.orderdetail();
        CAI.SHOP.BLL.orderdetail orderdetailbll=new CAI.SHOP.BLL.orderdetail();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("ssnotice.aspx");
            }
            else
            {

                if (!Page.IsPostBack)
                {
                    Panel3.Visible = false;
                    Panel1.Visible = false;
                }
            }
        }

        protected void shoplist()
        {
            Hashtable Hash;
            if (Session["car"] == null)
            {
                Hash = new Hashtable();
            }
            else
            {
                Hash = (Hashtable)Session["car"];
            }


            string[] ArrKey = new string[Hash.Count];
            int[] ArrVal = new int[Hash.Count];
            string Products = "('";
            Hash.Keys.CopyTo(ArrKey, 0);
            Hash.Values.CopyTo(ArrVal, 0);
            int k = 0;
            for (int j = 0; j < ArrKey.Length; j++)
            {
                if (k > 0) Products += "','"; k++;
                Products += ArrKey.GetValue(j).ToString();
            }
            Products += "')";
            //string strconn = "Provider=Microsoft.Jet.OleDb.4.0;Data Source=" + Server.MapPath("App_Data/shopping.mdb");
            //string strsql = "Select * From 商品 Where 编号 In " + Products;
            //OleDbConnection myConnection = new OleDbConnection(strconn);
            //OleDbCommand myCommand = new OleDbCommand(strsql, myConnection);
            //myConnection.Open();
            DataSet ds = productbll.GetList("pid in" + Products);
            DataTable Table1 = new DataTable();
            Table1 = ds.Tables[0];
            Table1.Columns.Add(new DataColumn("shuliang", System.Type.GetType("System.Int32")));
            Table1.Columns.Add(new DataColumn("shuliang1", System.Type.GetType("System.Int32")));
            DataColumn[] Keys = { Table1.Columns["pid"] };
            Table1.PrimaryKey = Keys;
            foreach (string X in Hash.Keys)
            {
                Table1.Rows.Find(X)["shuliang"] = Hash[X];
                Table1.Rows.Find(X)["shuliang1"] = Hash[X];

            }
            Table1.Columns.Add(new DataColumn("zongjia", System.Type.GetType("System.Double"), "hotprice*shuliang"));
            Table1.Columns.Add(new DataColumn("zongji", System.Type.GetType("System.Double"), "jifen*shuliang"));
            for (int I = 0; I < Table1.Rows.Count; I++)
            {
                jifena += Convert.ToDouble(Table1.Rows[I]["zongji"]);
                TtlPrice += Convert.ToDouble(Table1.Rows[I]["zongjia"]);
            }
            // Session["TtlPrice"]=
            double ztg = Convert.ToDouble(TtlPrice.ToString()) + Convert.ToDouble(RadioButtonList1.SelectedValue.ToString());
            Label3.Text = ztg.ToString();
            Label1.Text = "应付总额:" + TtlPrice.ToString() + "元+" + RadioButtonList1.SelectedValue.ToString() + "元(邮费)=" + ztg.ToString() + "元";
            Label12.Text = jifena.ToString();
            MyGrid.DataSource = Table1.DefaultView;
            MyGrid.DataBind();
        }
        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {

          
          
            //下订单代码
            DataSet ds = userbll.GetList("username='" + Session["username"].ToString() + "'");
          
                //添加订单 ORDERS表信息
                string userid = ds.Tables[0].Rows[0]["uid"].ToString();

                DateTime ordertime = DateTime.Now;
                string orderid = ordertime.ToString("yyyymmddhhmmss");
                //decimal dingdantotal = Convert.ToDecimal(Label1.Text.ToString());

            ordersmodel.orderid=orderid;
            ordersmodel.username=Session["username"].ToString();
            ordersmodel.userid=Convert.ToInt32(userid);
            ordersmodel.shouhuoname=TextBox5.Text;
            ordersmodel.telephone=TextBox6.Text;
            ordersmodel.address=Label4.Text;
            ordersmodel.postcode=TextBox1.Text;
            ordersmodel.songhuofs=RadioButtonList1.SelectedItem.Text;
            ordersmodel.fukuanfs=RadioButtonList2.SelectedItem.Text;
            ordersmodel.dingdanshijian=ordertime;
            ordersmodel.dingdantotal=Convert.ToDecimal(Label3.Text);
            ordersmodel.beizhu=TextBox3.Text;
            ordersmodel.djifen=Convert.ToInt32(Label12.Text);

            ordersbll.Add(ordersmodel);

            
            DataSet dsb =ordersbll.GetList("orderid='"+orderid+"'");

             string uoid = dsb.Tables[0].Rows[0]["oid"].ToString();
                    DataSet dsa=ordersbll.GetList("oid='"+uoid+"'");
                    
                     Label5.Text =dsa.Tables[0].Rows[0]["orderid"].ToString();
                     Label6.Text = dsa.Tables[0].Rows[0]["dingdantotal"].ToString();
                  

                    for (int i = 0; i < MyGrid.Rows.Count; i++)
                    {

                        Label pid = (Label)MyGrid.Rows[i].FindControl("label1");
                        Label shuliang = (Label)MyGrid.Rows[i].FindControl("shuliang");
                        Label xiaoji = (Label)MyGrid.Rows[i].FindControl("label2");

                        int pids = Convert.ToInt32(pid.Text);
                        int shulianga = Convert.ToInt32(shuliang.Text);
                        double xiaojia = Convert.ToDouble(xiaoji.Text);

                        orderdetailmodel.pid=pids;
                        orderdetailmodel.shuliang=shulianga;
                        orderdetailmodel.orderid=orderid;
                        orderdetailmodel.producttotail=Convert.ToDecimal(xiaojia);
                        int b=orderdetailbll.Add(orderdetailmodel);
                       
                        if (b > 0 && RadioButtonList2.SelectedValue == "1")
                        {
                            Panel3.Visible = true;
                            //Response.Write("<script>alert('下订单成功!');location.href='mydingdan.aspx'</script>");

                            //  Page.RegisterClientScriptBlock("e", "<script>alert('下订单成功');lo</script>");
                            //Server.Transfer("mydingdan.aspx");
                            // Label5.Text=
                            Panel1.Visible = false;
                            Session["car"] = null;
                        }
                        else
                        {
                            Response.Write("<script>alert('下订单成功!');location.href='mydingdan.aspx'</script>");
                            Session["car"] = null;

                        }


                    }

                }



    


        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Panel1.Visible = false;
            Panel2.Visible = true;
            shoplist();
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            Panel1.Visible = true;
            Panel2.Visible = false;
            Label7.Text = TextBox5.Text;
            Label8.Text = TextBox6.Text;
            Label9.Text = TextBox1.Text;
            Label10.Text = RadioButtonList2.SelectedItem.Text;
            shoplist();
            Label4.Text = Session["dizhi"].ToString() + TextBox4.Text;
        }
    }
}
